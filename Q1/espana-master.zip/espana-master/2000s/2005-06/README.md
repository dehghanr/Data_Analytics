

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FC Barcelona                  38  15  3  1  45:15   10  4  5  35:20    80:35  +45   82
 2. Real Madrid CF                38  11  4  4  40:21    9  6  4  30:19    70:40  +30   70
 3. Valencia CF                   38  10  8  1  34:16    9  4  6  24:17    58:33  +25   69
 4. Sevilla FC                    38  12  5  2  29:15    8  3  8  25:24    54:39  +15   68
 5. CA Osasuna                    38  12  3  4  28:20    9  2  8  21:23    49:43   +6   68
 6. RC Celta Vigo                 38  13  0  6  25:13    7  4  8  20:20    45:33  +12   64
 7. Villarreal CF                 38   9  6  4  28:18    5  9  5  22:21    50:39  +11   57
 8. RCD La Coruña                 38   6  5  8  19:22    9  5  5  28:23    47:45   +2   55
 9. Getafe CF                     38   8  7  4  32:24    7  2 10  22:25    54:49   +5   54
10. Atlético Madrid               38   7  6  6  21:18    6  7  6  24:19    45:37   +8   52
11. Real Zaragoza                 38   6  6  7  26:26    4 10  5  20:25    46:51   -5   46
12. Athletic Club Bilbao          38   7  6  6  19:18    4  6  9  21:28    40:46   -6   45
13. RCD Mallorca                  38   6  8  5  21:21    4  5 10  16:30    37:51  -14   43
14. Real Betis                    38   8  5  6  19:19    2  7 10  15:32    34:51  -17   42
15. RCD Español                   38   7  4  8  26:24    3  7  9  10:32    36:56  -20   41
16. Real Racing Santander         38   4  6  9  18:26    5  7  7  18:23    36:49  -13   40
17. Real Sociedad                 38   8  4  7  31:27    3  3 13  17:38    48:65  -17   40
18. Deportivo Alavés              38   6  6  7  20:24    3  6 10  15:30    35:54  -19   39
19. Cádiz CF                      38   4  8  7  22:25    4  4 11  14:27    36:52  -16   36
20. Málaga CF                     38   3  5 11  16:25    2  4 13  20:43    36:68  -32   24
```

(Source: [`1-liga.csv`](1-liga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Recreativo Huelva             42  13  7  1  38:14    9  5  7  29:18    67:32  +35   78
 2. Gimnàstic Tarragona           42  12  4  5  27:20   11  3  7  21:18    48:38  +10   76
 3. Levante UD                    42  13  5  3  35:17    7  9  5  18:22    53:39  +14   74
 4. CF Ciudad de Murcia           42  13  3  5  32:18    7  9  5  21:24    53:42  +11   72
 5. Lorca FC                      42  11  8  2  31:16    8  4  9  25:23    56:39  +17   69
 6. Xerez CD                      42  10  8  3  28:14    8  5  8  32:32    60:46  +14   67
 7. UD Almería                    42  16  1  4  40:17    4  6 11  14:26    54:43  +11   67
 8. CD Numancia                   42  12  4  5  28:19    6  5 10  22:36    50:55   -5   63
 9. Sporting Gijón                42   8 11  2  26:17    5  6 10  15:17    41:34   +7   56
10. Real Madrid CF B              42  10  4  7  32:19    6  3 12  23:31    55:50   +5   55
11. Real Valladolid CF            42   7  8  6  26:26    7  5  9  28:28    54:54        55
12. CD Castellón                  42  10  6  5  24:18    4  6 11  22:32    46:50   -4   54
13. Albacete Balompié             42  11  5  5  27:20    3  7 11  17:37    44:57  -13   54
14. Elche CF                      42   9  8  4  28:21    4  6 11  19:33    47:54   -7   53
15. Polideportivo Ejido           42   9  3  9  28:26    6  5 10  15:24    43:50   -7   53
16. Real Murcia CF                42  11  6  4  29:15    2  7 12  12:25    41:40   +1   52
17. Hércules CF                   42  10  6  5  27:20    3  7 11  12:29    39:49  -10   52
18. CD Tenerife                   42   9  6  6  30:25    4  6 11  23:35    53:60   -7   51
19. UE Lleida                     42   7  6  8  21:22    5  4 12  22:31    43:53  -10   46
20. Racing Ferrol                 42   3 10  8  22:29    4  6 11  22:34    44:63  -19   37
21. Málaga CF B                   42   6  5 10  22:28    2  7 12  20:40    42:68  -26   36
22. SD Eibar                      42   3  7 11  15:24    3 10  8  13:21    28:45  -17   35
```

(Source: [`2-liga2.csv`](2-liga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

