

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Valencia CF                   38  12  3  4  38:16   11  5  3  33:11    71:27  +44   77
 2. FC Barcelona                  38  10  6  3  33:14   11  3  5  30:25    63:39  +24   72
 3. RCD La Coruña                 38  13  3  3  36:15    8  5  6  24:19    60:34  +26   71
 4. Real Madrid CF                38  13  2  4  43:26    8  5  6  29:28    72:54  +18   70
 5. Athletic Club Bilbao          38  10  5  4  32:20    5  6  8  21:29    53:49   +4   56
 6. Sevilla FC                    38  12  2  5  30:15    3  8  8  26:30    56:45  +11   55
 7. Atlético Madrid               38  11  5  3  30:17    4  5 10  21:36    51:53   -2   55
 8. Villarreal CF                 38  10  5  4  28:19    5  4 10  19:30    47:49   -2   54
 9. Real Betis                    38   6  9  4  22:20    7  4  8  24:23    46:43   +3   52
10. Málaga CF                     38  10  4  5  35:27    5  2 12  15:28    50:55   -5   51
11. RCD Mallorca                  38   7  5  7  29:32    8  1 10  25:34    54:66  -12   51
12. CA Osasuna                    38   6  7  6  24:24    5  8  6  14:13    38:37   +1   48
13. Real Zaragoza                 38   7  7  5  25:20    6  2 11  21:35    46:55   -9   48
14. Albacete Balompié             38   9  2  8  25:21    4  6  9  15:27    40:48   -8   47
15. Real Sociedad                 38   7  7  5  24:22    4  6  9  25:31    49:53   -4   46
16. Real Racing Santander         38   5  4 10  23:32    6  6  7  25:31    48:63  -15   43
17. RCD Español                   38   8  2  9  24:26    5  2 12  24:38    48:64  -16   43
18. Real Valladolid CF            38   7  6  6  25:23    3  5 11  21:33    46:56  -10   41
19. RC Celta Vigo                 38   4  4 11  16:38    5  8  6  32:30    48:68  -20   39
20. Real Murcia CF                38   5  7  7  21:25    0  4 15   8:32    29:57  -28   26
```

(Source: [`1-liga.csv`](1-liga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Levante UD                    42  14  6  1  32:12    8  7  6  27:21    59:33  +26   79
 2. CD Numancia                   42  14  5  2  37:8     8  5  8  23:22    60:30  +30   76
 3. Getafe CF                     42  12  8  1  33:15    8  8  5  22:23    55:38  +17   76
 4. Deportivo Alavés              42  12  7  2  27:12    8  7  6  21:20    48:32  +16   74
 5. Sporting Gijón                42  13  5  3  31:14    7  5  9  27:26    58:40  +18   70
 6. Recreativo Huelva             42  10  9  2  23:10    4 11  6  22:24    45:34  +11   62
 7. Cádiz CF                      42  11  6  4  34:22    6  4 11  18:25    52:47   +5   61
 8. CD Tenerife                   42   9  8  4  24:18    2 13  6  16:22    40:40        54
 9. Xerez CD                      42   8  7  6  25:21    4 11  6  22:28    47:49   -2   54
10. SD Eibar                      42   6 11  4  25:17    6  5 10  19:22    44:39   +5   52
11. UD Salamanca                  42   7  8  6  27:20    3 13  5  20:24    47:44   +3   51
12. UD Almería                    42   8  6  7  30:27    3 11  7  15:22    45:49   -4   50
13. Terrassa FC                   42   5 11  5  21:20    7  3 11  24:30    45:50   -5   50
14. Elche CF                      42   9  6  6  32:27    4  5 12  18:36    50:63  -13   50
15. Córdoba CF                    42   7  7  7  22:20    4  9  8  15:22    37:42   -5   49
16. Málaga CF B                   42   5 11  5  25:28    6  5 10  21:28    46:56  -10   49
17. Polideportivo Ejido           42   9  5  7  19:19    3  8 10  10:21    29:40  -11   49
18. CF Ciudad de Murcia           42   6  8  7  30:29    5  8  8  21:34    51:63  -12   49
19. CD Leganés                    42   4 10  7  14:20    5  9  7  22:27    36:47  -11   46
20. UD Las Palmas                 42   5  9  7  25:30    5  5 11  21:38    46:68  -22   44
21. Rayo Vallecano                42   8  5  8  28:27    3  5 13  17:36    45:63  -18   43
22. Algeciras CF                  42   5  7  9  21:23    1  8 12  18:34    39:57  -18   33
```

(Source: [`2-liga2.csv`](2-liga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

