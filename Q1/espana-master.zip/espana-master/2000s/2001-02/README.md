

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Valencia CF                   38  14  4  1  28:8     7  8  4  23:19    51:27  +24   75
 2. RCD La Coruña                 38  13  4  2  40:13    7  4  8  25:28    65:41  +24   68
 3. Real Madrid CF                38  14  5  0  48:14    5  4 10  21:30    69:44  +25   66
 4. FC Barcelona                  38  12  5  2  44:17    6  5  8  21:20    65:37  +28   64
 5. RC Celta Vigo                 38  10  5  4  36:21    6  7  6  28:25    64:46  +18   60
 6. Real Betis                    38  11  5  3  26:13    4  9  6  16:21    42:34   +8   59
 7. Deportivo Alavés              38  10  1  8  22:21    7  2 10  19:23    41:44   -3   54
 8. Sevilla FC                    38   7  6  6  26:18    7  5  7  25:22    51:40  +11   53
 9. Málaga CF                     38   8  7  4  24:20    5  7  7  20:24    44:44        53
10. Athletic Club Bilbao          38   6  7  6  23:29    8  4  7  31:37    54:66  -12   53
11. Rayo Vallecano                38  11  3  5  27:19    2  7 10  19:33    46:52   -6   49
12. Real Valladolid CF            38   9  4  6  24:20    4  5 10  21:38    45:58  -13   48
13. Real Sociedad                 38   8  6  5  31:22    5  2 12  17:32    48:54   -6   47
14. RCD Español                   38  12  2  5  34:20    1  6 12  13:36    47:56   -9   47
15. Villarreal CF                 38   9  6  4  30:21    2  4 13  16:34    46:55   -9   43
16. RCD Mallorca                  38   7  5  7  24:23    4  5 10  16:29    40:52  -12   43
17. CA Osasuna                    38   6  6  7  19:21    4  6  9  17:28    36:49  -13   42
18. UD Las Palmas                 38   7  8  4  23:17    2  5 12  17:33    40:50  -10   40
19. CD Tenerife                   38   6  5  8  21:30    4  3 12  11:28    32:58  -26   38
20. Real Zaragoza                 38   6  7  6  21:23    3  3 13  14:31    35:54  -19   37
```

(Source: [`1-liga.csv`](1-liga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Atlético Madrid               42  11  8  2  33:19   12  2  7  35:25    68:44  +24   79
 2. Real Racing Santander         42  14  4  3  37:17    5 10  6  21:20    58:37  +21   71
 3. Recreativo Huelva             42  12  3  6  23:18    6 12  3  24:17    47:35  +12   69
 4. Xerez CD                      42  14  2  5  29:18    5  7  9  14:24    43:42   +1   66
 5. Elche CF                      42  11  8  2  33:14    6  6  9  19:25    52:39  +13   65
 6. Sporting Gijón                42   8  8  5  28:19    9  5  7  29:28    57:47  +10   64
 7. SD Eibar                      42  11  6  4  34:16    3 10  8   7:11    41:27  +14   58
 8. Real Oviedo                   42   7 10  4  21:19    6  9  6  20:21    41:40   +1   58
 9. Albacete Balompié             42  11  5  5  29:15    4  6 11  14:27    43:42   +1   56
10. Racing Ferrol                 42  11  4  6  32:20    5  4 12  26:40    58:60   -2   56
11. UD Salamanca                  42   7  7  7  23:19    6  8  7  29:34    52:53   -1   54
12. Córdoba CF                    42   8  6  7  26:24    6  5 10  20:27    46:51   -5   53
13. CD Leganés                    42   8  6  7  21:22    5  8  8  19:24    40:46   -6   53
14. CD Badajoz                    42   8  5  8  27:28    7  3 11  16:24    43:52   -9   53
15. Real Murcia CF                42   7  8  6  24:19    5  8  8  13:19    37:38   -1   52
16. Burgos CF                     42   4 10  7  12:18    8  6  7  19:19    31:37   -6   52
17. CD Numancia                   42   7  7  7  24:22    6  5 10  21:31    45:53   -8   51
18. Polideportivo Ejido           42   8  9  4  24:17    4  5 12  17:31    41:48   -7   50
19. Levante UD                    42   4 10  7  21:23    8  4  9  20:31    41:54  -13   50
20. Gimnàstic Tarragona           42   8  7  6  24:20    4  6 11  21:29    45:49   -4   49
21. CF Extremadura                42   9  3  9  23:23    1 10 10  14:27    37:50  -13   43
22. Real Jaén CF                  42   5  6 10  15:23    6  3 12  15:29    30:52  -22   42
```

(Source: [`2-liga2.csv`](2-liga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

