

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Real Madrid CF                38  17  0  2  53:18   10  4  5  31:18    84:36  +48   85
 2. Villarreal CF                 38  12  5  2  33:15   12  0  7  30:25    63:40  +23   77
 3. FC Barcelona                  38  14  2  3  46:12    5  8  6  30:31    76:43  +33   67
 4. Sevilla FC                    38  13  1  5  46:20    7  3  9  29:29    75:49  +26   64
 5. Atlético Madrid               38  12  2  5  45:26    7  5  7  21:21    66:47  +19   64
 6. Real Racing Santander         38  11  3  5  24:18    6  6  7  18:23    42:41   +1   60
 7. RCD Mallorca                  38   9  6  4  35:22    6  8  5  34:32    69:54  +15   59
 8. RCD La Coruña                 38   9  3  7  24:23    6  4  9  22:24    46:47   -1   52
 9. UD Almería                    38   9  5  5  18:14    5  5  9  24:31    42:45   -3   52
10. Valencia CF                   38   7  3  9  24:31    8  3  8  24:31    48:62  -14   51
11. Athletic Club Bilbao          38   7  8  4  22:14    6  3 10  18:29    40:43   -3   50
12. RCD Español                   38   8  3  8  21:23    5  6  8  22:30    43:53  -10   48
13. Getafe CF                     38   7  7  5  24:22    5  4 10  20:26    44:48   -4   47
14. Real Betis                    38   7  4  8  27:26    5  7  7  18:25    45:51   -6   47
15. Real Valladolid CF            38   6  9  4  19:18    5  3 11  23:39    42:57  -15   45
16. Recreativo Huelva             38   6  7  6  24:25    5  4 10  16:35    40:60  -20   44
17. CA Osasuna                    38   8  4  7  25:21    4  3 12  12:23    37:44   -7   43
18. Real Zaragoza                 38   9  7  3  36:24    1  5 13  14:37    50:61  -11   42
19. Real Murcia CF                38   6  4  9  21:26    1  5 13  15:39    36:65  -29   30
20. Levante UD                    38   5  4 10  22:34    2  1 16  11:41    33:75  -42   26
```

(Source: [`1-liga.csv`](1-liga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. CD Numancia                   42  11  4  6  27:21   11  7  3  32:17    59:38  +21   77
 2. Sporting Gijón                42  11  5  5  31:18    9  7  5  30:22    61:40  +21   72
 3. Málaga CF                     42  12  5  4  37:21    8  7  6  21:21    58:42  +16   72
 4. Real Sociedad                 42  10  6  5  28:17    8  8  5  27:22    55:39  +16   68
 5. CD Castellón                  42  12  7  2  23:11    4  6 11  19:26    42:37   +5   61
 6. Hércules CF                   42   7  7  7  30:25    7  9  5  36:30    66:55  +11   58
 7. UD Salamanca                  42   9  8  4  32:22    4 10  7  20:22    52:44   +8   57
 8. UD Las Palmas                 42   9  6  6  26:21    6  6  9  25:34    51:55   -4   57
 9. Sevilla FC B                  42   9  8  4  31:24    5  6 10  12:24    43:48   -5   56
10. Elche CF                      42  10  6  5  29:24    4  6 11  15:26    44:50   -6   54
11. CD Tenerife                   42  11  6  4  33:24    1 11  9  18:33    51:57   -6   53
12. RC Celta Vigo                 42   7  9  5  33:25    6  4 11  23:30    56:55   +1   52
13. Gimnàstic Tarragona           42   9  7  5  30:22    3  9  9  19:29    49:51   -2   52
14. Albacete Balompié             42   9  4  8  23:23    4  9  8  14:17    37:40   -3   52
15. Xerez CD                      42  10  7  4  27:25    2  9 10  20:31    47:56   -9   52
16. SD Eibar                      42  11  4  6  27:21    3  6 12  15:30    42:51   -9   52
17. Deportivo Alavés              42   8 10  3  22:16    4  5 12  19:31    41:47   -6   51
18. Racing Ferrol                 42   6  9  6  21:23    6  5 10  25:28    46:51   -5   50
19. Córdoba CF                    42   6 10  5  28:29    5  7  9  22:27    50:56   -6   50
20. Cádiz CF                      42   8  7  6  23:17    4  6 11  17:30    40:47   -7   49
21. Granada 74                    42   7 10  4  24:22    3  5 13  21:37    45:59  -14   45
22. Polideportivo Ejido           42   9  7  5  21:15    2  4 15  16:39    37:54  -17   44
```

(Source: [`2-liga2.csv`](2-liga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

