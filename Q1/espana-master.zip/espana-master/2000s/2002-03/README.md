

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Real Madrid CF                38  13  5  1  52:22    9  7  3  34:20    86:42  +44   78
 2. Real Sociedad                 38  13  6  0  41:18    9  4  6  30:27    71:45  +26   76
 3. RCD La Coruña                 38  13  3  3  41:18    9  3  7  26:29    67:47  +20   72
 4. RC Celta Vigo                 38  10  6  3  29:15    7  4  8  16:21    45:36   +9   61
 5. Valencia CF                   38  10  3  6  30:15    7  6  6  26:20    56:35  +21   60
 6. FC Barcelona                  38  10  5  4  43:24    5  6  8  20:23    63:47  +16   56
 7. Athletic Club Bilbao          38  11  3  5  30:20    4  7  8  33:41    63:61   +2   55
 8. Real Betis                    38   9  6  4  31:21    5  6  8  25:32    56:53   +3   54
 9. RCD Mallorca                  38   7  5  7  25:33    7  5  7  24:23    49:56   -7   52
10. Sevilla FC                    38   8  7  4  24:19    5  4 10  14:20    38:39   -1   50
11. Atlético Madrid               38   8  5  6  28:25    4  6  9  23:31    51:56   -5   47
12. CA Osasuna                    38   8  3  8  22:24    4  8  7  18:24    40:48   -8   47
13. Real Valladolid CF            38   9  4  6  23:17    3  6 10  14:23    37:40   -3   46
14. Málaga CF                     38   8  7  4  29:21    3  6 10  15:28    44:49   -5   46
15. Villarreal CF                 38   8  5  6  24:21    3  7  9  20:32    44:53   -9   45
16. Real Racing Santander         38   9  2  8  29:22    4  3 12  25:42    54:64  -10   44
17. RCD Español                   38   8  6  5  30:23    2  7 10  18:31    48:54   -6   43
18. Recreativo Huelva             38   5  8  6  24:24    3  4 12  11:37    35:61  -26   36
19. Deportivo Alavés              38   5  8  6  18:20    3  3 13  20:48    38:68  -30   35
20. Rayo Vallecano                38   4  8  7  17:24    3  3 13  14:38    31:62  -31   32
```

(Source: [`1-liga.csv`](1-liga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Real Murcia CF                42  14  5  2  38:8     9  5  7  21:14    59:22  +37   79
 2. Real Zaragoza                 42  11  6  4  30:19    9  6  6  24:21    54:40  +14   72
 3. Albacete Balompié             42   9 10  2  25:11    8 10  3  26:19    51:30  +21   71
 4. Levante UD                    42  11  7  3  35:20    5 10  6  24:24    59:44  +15   65
 5. UD Las Palmas                 42  10  6  5  32:21    6 10  5  21:22    53:43  +10   64
 6. Xerez CD                      42   9  8  4  33:25    8  5  8  22:28    55:53   +2   64
 7. UD Salamanca                  42   7  9  5  22:17    7  9  5  22:15    44:32  +12   60
 8. CD Tenerife                   42   9 11  1  34:15    4  7 10  19:24    53:39  +14   57
 9. SD Compostela                 42   8  6  7  28:24    6  7  8  26:32    54:56   -2   55
10. Sporting Gijón                42   7 11  3  24:17    4  9  8  20:24    44:41   +3   53
11. Getafe CF                     42   9  7  5  30:23    4  7 10  22:32    52:55   -3   53
12. CD Numancia                   42   9  6  6  29:26    3 10  8  19:26    48:52   -4   52
13. Terrassa FC                   42   8  8  5  21:20    3 11  7  20:26    41:46   -5   52
14. Polideportivo Ejido           42   9  7  5  19:13    3  9  9  17:32    36:45   -9   52
15. Córdoba CF                    42   6  7  8  19:22    6  7  8  17:16    36:38   -2   50
16. Elche CF                      42   7  7  7  26:23    5  7  9  23:29    49:52   -3   50
17. SD Eibar                      42   7 10  4  19:14    4  7 10  14:24    33:38   -5   50
18. UD Almería                    42   8  7  6  31:26    4  7 10  23:37    54:63   -9   50
19. CD Leganés                    42   6  6  9  22:26    5  9  7  22:25    44:51   -7   48
20. Racing Ferrol                 42   8  8  5  22:20    3  5 13  18:40    40:60  -20   46
21. Real Oviedo                   42   4  7 10  20:32    5  6 10  17:27    37:59  -22   40
22. CD Badajoz                    42   5  6 10  18:31    5  2 14  16:40    34:71  -37   38
```

(Source: [`2-liga2.csv`](2-liga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

