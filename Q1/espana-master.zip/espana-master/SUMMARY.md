# Summary

25 seasons, 2 levels (1 2), 87 teams in 47 datafiles

level 1
- 25 seasons: 2017-18 2016-17 2015-16 2014-15 2013-14 2012-13 2011-12 2010-11 2009-10 2008-09 2007-08 2006-07 2005-06 2004-05 2003-04 2002-03 2001-02 2000-01 1999-00 1998-99 1997-98 1996-97 1995-96 1994-95 1993-94 
- 47 teams: Albacete Balompié (5) Athletic Club Bilbao (25) Atlético Madrid (23) CA Osasuna (16) CD Leganés (2) CD Logroñés (3) CD Numancia (4) CD Tenerife (8) CF Extremadura (2) CP Mérida (2) Cádiz CF (1) Córdoba CF (1) Deportivo Alavés (8) Elche CF (2) FC Barcelona (25) Getafe CF (13) Gimnàstic Tarragona (1) Girona FC (1) Granada CF (6) Hércules CF (2) Levante UD (10) Málaga CF (17) RC Celta Vigo (19) RCD Español (24) RCD La Coruña (23) RCD Mallorca (16) Rayo Vallecano (12) Real Betis (20) Real Madrid CF (25) Real Murcia CF (2) Real Oviedo (8) Real Racing Santander (18) Real Sociedad (22) Real Valladolid CF (16) Real Zaragoza (18) Recreativo Huelva (4) SD Compostela (4) SD Eibar (4) Sevilla FC (22) Sporting Gijón (11) UD Almería (6) UD Las Palmas (5) UD Salamanca (3) UE Lleida (1) Valencia CF (25) Villarreal CF (18) Xerez CD (1) 
  - 25 seasons: **Athletic Club Bilbao**, **FC Barcelona**, **Real Madrid CF**, **Valencia CF**
  - 24 seasons: **RCD Español**
  - 23 seasons: **Atlético Madrid**, **RCD La Coruña**
  - 22 seasons: **Real Sociedad**, **Sevilla FC**
  - 20 seasons: **Real Betis**
  - 19 seasons: **RC Celta Vigo**
  - 18 seasons: **Real Racing Santander**, **Real Zaragoza**, **Villarreal CF**
  - 17 seasons: **Málaga CF**
  - 16 seasons: **CA Osasuna**, **RCD Mallorca**, **Real Valladolid CF**
  - 13 seasons: **Getafe CF**
  - 12 seasons: **Rayo Vallecano**
  - 11 seasons: **Sporting Gijón**
  - 10 seasons: **Levante UD**
  - 8 seasons: **CD Tenerife**, **Deportivo Alavés**, **Real Oviedo**
  - 6 seasons: **Granada CF**, **UD Almería**
  - 5 seasons: **Albacete Balompié**, **UD Las Palmas**
  - 4 seasons: **CD Numancia**, **Recreativo Huelva**, **SD Compostela**, **SD Eibar**
  - 3 seasons: **CD Logroñés**, **UD Salamanca**
  - 2 seasons: **CD Leganés**, **CF Extremadura**, **CP Mérida**, **Elche CF**, **Hércules CF**, **Real Murcia CF**
  - 1 seasons: **Cádiz CF**, **Córdoba CF**, **Gimnàstic Tarragona**, **Girona FC**, **UE Lleida**, **Xerez CD**


level 2
- 22 seasons: 2017-18 2016-17 2015-16 2014-15 2013-14 2012-13 2011-12 2010-11 2009-10 2008-09 2007-08 2006-07 2005-06 2004-05 2003-04 2002-03 2001-02 2000-01 1999-00 1998-99 1997-98 1996-97 
- 82 teams: AD Alcorcón (8) Albacete Balompié (16) Algeciras CF (1) Alicante CF (1) Athletic Club Bilbao B (1) Atlético Madrid (2) Atlético Madrid B (4) Burgos CF (1) CA Osasuna (7) CD Alcoyano (1) CD Badajoz (7) CD Castellón (5) CD Guadalajara (2) CD Leganés (10) CD Logroñés (3) CD Lugo (6) CD Mirandés (5) CD Numancia (17) CD Ourense (3) CD Tenerife (15) CD Toledo (4) CE Sabadell (4) CF Ciudad de Murcia (4) CF Extremadura (4) CF Reus (2) CP Mérida (3) Cultural Leonesa (1) Cádiz CF (7) Córdoba CF (16) Deportivo Alavés (10) Elche CF (17) FC Barcelona B (8) FC Cartagena (3) Getafe CF (5) Gimnàstic Tarragona (11) Girona FC (9) Granada 74 (1) Granada CF (2) Hércules CF (10) Levante UD (11) Lorca FC (3) Málaga CF (3) Málaga CF B (3) Polideportivo Ejido (7) Pontevedra CF (1) RC Celta Vigo (6) RCD La Coruña (2) RCD Mallorca (5) RCD Mallorca B (1) Racing Ferrol (6) Rayo Vallecano (8) Real Betis (4) Real Jaén CF (4) Real Madrid CF B (5) Real Murcia CF (11) Real Oviedo (5) Real Racing Santander (3) Real Sociedad (3) Real Unión (1) Real Valladolid CF (9) Real Zaragoza (7) Recreativo Huelva (13) SD Compostela (4) SD Eibar (13) SD Huesca (8) SD Ponferradina (6) Sevilla FC (3) Sevilla FC B (4) Sporting Gijón (14) Terrassa FC (3) UCAM Murcia (1) UD Almería (11) UD Las Palmas (15) UD Salamanca (12) UD Vecindario (1) UE Llagostera (2) UE Lleida (7) Universidad Las Palmas (1) Villarreal CF (4) Villarreal CF B (3) Xerez CD (12) Écija Balompié (1) 
  - 17 seasons: **CD Numancia**, **Elche CF**
  - 16 seasons: **Albacete Balompié**, **Córdoba CF**
  - 15 seasons: **CD Tenerife**, **UD Las Palmas**
  - 14 seasons: **Sporting Gijón**
  - 13 seasons: **Recreativo Huelva**, **SD Eibar**
  - 12 seasons: **UD Salamanca**, **Xerez CD**
  - 11 seasons: **Gimnàstic Tarragona**, **Levante UD**, **Real Murcia CF**, **UD Almería**
  - 10 seasons: **CD Leganés**, **Deportivo Alavés**, **Hércules CF**
  - 9 seasons: **Girona FC**, **Real Valladolid CF**
  - 8 seasons: **AD Alcorcón**, **FC Barcelona B**, **Rayo Vallecano**, **SD Huesca**
  - 7 seasons: **CA Osasuna**, **CD Badajoz**, **Cádiz CF**, **Polideportivo Ejido**, **Real Zaragoza**, **UE Lleida**
  - 6 seasons: **CD Lugo**, **RC Celta Vigo**, **Racing Ferrol**, **SD Ponferradina**
  - 5 seasons: **CD Castellón**, **CD Mirandés**, **Getafe CF**, **RCD Mallorca**, **Real Madrid CF B**, **Real Oviedo**
  - 4 seasons: **Atlético Madrid B**, **CD Toledo**, **CE Sabadell**, **CF Ciudad de Murcia**, **CF Extremadura**, **Real Betis**, **Real Jaén CF**, **SD Compostela**, **Sevilla FC B**, **Villarreal CF**
  - 3 seasons: **CD Logroñés**, **CD Ourense**, **CP Mérida**, **FC Cartagena**, **Lorca FC**, **Málaga CF**, **Málaga CF B**, **Real Racing Santander**, **Real Sociedad**, **Sevilla FC**, **Terrassa FC**, **Villarreal CF B**
  - 2 seasons: **Atlético Madrid**, **CD Guadalajara**, **CF Reus**, **Granada CF**, **RCD La Coruña**, **UE Llagostera**
  - 1 seasons: **Algeciras CF**, **Alicante CF**, **Athletic Club Bilbao B**, **Burgos CF**, **CD Alcoyano**, **Cultural Leonesa**, **Granada 74**, **Pontevedra CF**, **RCD Mallorca B**, **Real Unión**, **UCAM Murcia**, **UD Vecindario**, **Universidad Las Palmas**, **Écija Balompié**


level 1 - 25 seasons:
- [`2017-18/1-liga.csv`](2017-18/1-liga.csv) =>  20 teams,  380 matches,  1024 goals,  38 rounds,  Fri 18 Aug 2017 - Sun 20 May 2018
- [`2016-17/1-liga.csv`](2016-17/1-liga.csv) =>  20 teams,  380 matches,  1118 goals,  38 rounds,  Fri 19 Aug 2016 - Sun 21 May 2017
- [`2015-16/1-liga.csv`](2015-16/1-liga.csv) =>  20 teams,  380 matches,  1043 goals,  38 rounds,  Fri 21 Aug 2015 - Sun 15 May 2016
- [`2014-15/1-liga.csv`](2014-15/1-liga.csv) =>  20 teams,  380 matches,  1009 goals,  38 rounds,  Sat 23 Aug 2014 - Sat 23 May 2015
- [`2013-14/1-liga.csv`](2013-14/1-liga.csv) =>  20 teams,  380 matches,  1045 goals,  38 rounds,  Sat 17 Aug 2013 - Sun 18 May 2014
- [`2012-13/1-liga.csv`](2012-13/1-liga.csv) =>  20 teams,  380 matches,  1091 goals,  38 rounds,  Sat 18 Aug 2012 - Sat 01 Jun 2013
- [`2011-12/1-liga.csv`](2011-12/1-liga.csv) =>  20 teams,  380 matches,  1050 goals,  38 rounds,  Sat 27 Aug 2011 - Sun 13 May 2012
- [`2010-11/1-liga.csv`](2010-11/1-liga.csv) =>  20 teams,  380 matches,  1042 goals,  38 rounds,  Sat 28 Aug 2010 - Sat 21 May 2011
- [`2009-10/1-liga.csv`](2009-10/1-liga.csv) =>  20 teams,  380 matches,  1031 goals,  38 rounds,  Sat 29 Aug 2009 - Sun 16 May 2010
- [`2008-09/1-liga.csv`](2008-09/1-liga.csv) =>  20 teams,  380 matches,  1101 goals,  38 rounds,  Sat 30 Aug 2008 - Sun 31 May 2009
- [`2007-08/1-liga.csv`](2007-08/1-liga.csv) =>  20 teams,  380 matches,  1021 goals,  38 rounds,  Sat 25 Aug 2007 - Sun 18 May 2008
- [`2006-07/1-liga.csv`](2006-07/1-liga.csv) =>  20 teams,  380 matches,  942 goals,  38 rounds,  Sat 26 Aug 2006 - Sun 17 Jun 2007
- [`2005-06/1-liga.csv`](2005-06/1-liga.csv) =>  20 teams,  380 matches,  936 goals,  38 rounds,  Sat 27 Aug 2005 - Sat 20 May 2006
- [`2004-05/1-liga.csv`](2004-05/1-liga.csv) =>  20 teams,  380 matches,  980 goals,  38 rounds,  Sat 28 Aug 2004 - Sun 29 May 2005
- [`2003-04/1-liga.csv`](2003-04/1-liga.csv) =>  20 teams,  380 matches,  1015 goals,  38 rounds,  Sat 30 Aug 2003 - Sun 23 May 2004
- [`2002-03/1-liga.csv`](2002-03/1-liga.csv) =>  20 teams,  380 matches,  1016 goals,  38 rounds,  Sat 31 Aug 2002 - Sun 22 Jun 2003
- [`2001-02/1-liga.csv`](2001-02/1-liga.csv) =>  20 teams,  380 matches,  961 goals,  38 rounds,  Sat 25 Aug 2001 - Sat 11 May 2002
- [`2000-01/1-liga.csv`](2000-01/1-liga.csv) =>  20 teams,  380 matches,  1095 goals,  38 rounds,  Sat 09 Sep 2000 - Sun 17 Jun 2001
- [`1999-00/1-liga.csv`](1999-00/1-liga.csv) =>  20 teams,  380 matches,  999 goals,  38 rounds,  Sat 21 Aug 1999 - Sat 20 May 2000
- [`1998-99/1-liga.csv`](1998-99/1-liga.csv) =>  20 teams,  380 matches,  1003 goals,  38 rounds,  Sat 29 Aug 1998 - Sun 20 Jun 1999
- [`1997-98/1-liga.csv`](1997-98/1-liga.csv) =>  20 teams,  380 matches,  1009 goals,  38 rounds,  Sat 30 Aug 1997 - Sat 16 May 1998
- [`1996-97/1-liga.csv`](1996-97/1-liga.csv) =>  22 teams,  462 matches,  1271 goals,  42 rounds,  Sat 31 Aug 1996 - Mon 23 Jun 1997
- [`1995-96/1-liga.csv`](1995-96/1-liga.csv) =>  22 teams,  462 matches,  1246 goals,  42 rounds,  Sat 02 Sep 1995 - Sun 26 May 1996
- [`1994-95/1-liga.csv`](1994-95/1-liga.csv) =>  20 teams,  380 matches,  966 goals,  38 rounds,  Sat 03 Sep 1994 - Sun 18 Jun 1995
- [`1993-94/1-liga.csv`](1993-94/1-liga.csv) =>  20 teams,  380 matches,  988 goals,  38 rounds,  Sun 05 Sep 1993 - Sun 15 May 1994


level 2 - 22 seasons:
- [`2017-18/2-liga2.csv`](2017-18/2-liga2.csv) =>  22 teams,  462 matches,  1066 goals,  42 rounds,  Fri 18 Aug 2017 - Sat 02 Jun 2018
- [`2016-17/2-liga2.csv`](2016-17/2-liga2.csv) =>  22 teams,  462 matches,  1041 goals,  42 rounds,  Fri 19 Aug 2016 - Sun 11 Jun 2017
- [`2015-16/2-liga2.csv`](2015-16/2-liga2.csv) =>  22 teams,  462 matches,  1043 goals,  42 rounds,  Sat 22 Aug 2015 - Sat 04 Jun 2016
- [`2014-15/2-liga2.csv`](2014-15/2-liga2.csv) =>  22 teams,  462 matches,  1136 goals,  42 rounds,  Sat 23 Aug 2014 - Sun 07 Jun 2015
- [`2013-14/2-liga2.csv`](2013-14/2-liga2.csv) =>  22 teams,  462 matches,  1078 goals,  42 rounds,  Fri 16 Aug 2013 - Sun 08 Jun 2014
- [`2012-13/2-liga2.csv`](2012-13/2-liga2.csv) =>  22 teams,  462 matches,  1203 goals,  42 rounds,  Fri 17 Aug 2012 - Sun 09 Jun 2013
- [`2011-12/2-liga2.csv`](2011-12/2-liga2.csv) =>  22 teams,  462 matches,  1218 goals,  42 rounds,  Fri 26 Aug 2011 - Sun 03 Jun 2012
- [`2010-11/2-liga2.csv`](2010-11/2-liga2.csv) =>  22 teams,  462 matches,  1220 goals,  42 rounds,  Fri 27 Aug 2010 - Sat 04 Jun 2011
- [`2009-10/2-liga2.csv`](2009-10/2-liga2.csv) =>  22 teams,  462 matches,  1114 goals,  42 rounds,  Sat 29 Aug 2009 - Sat 19 Jun 2010
- [`2008-09/2-liga2.csv`](2008-09/2-liga2.csv) =>  22 teams,  462 matches,  1160 goals,  42 rounds,  Sat 30 Aug 2008 - Sun 21 Jun 2009
- [`2007-08/2-liga2.csv`](2007-08/2-liga2.csv) =>  22 teams,  462 matches,  1072 goals,  42 rounds,  Sat 25 Aug 2007 - Sun 15 Jun 2008
- [`2006-07/2-liga2.csv`](2006-07/2-liga2.csv) =>  22 teams,  462 matches,  1133 goals,  42 rounds,  Sat 26 Aug 2006 - Sun 17 Jun 2007
- [`2005-06/2-liga2.csv`](2005-06/2-liga2.csv) =>  22 teams,  462 matches,  1061 goals,  42 rounds,  Sat 27 Aug 2005 - Sun 18 Jun 2006
- [`2004-05/2-liga2.csv`](2004-05/2-liga2.csv) =>  22 teams,  462 matches,  1055 goals,  42 rounds,  Sat 28 Aug 2004 - Sat 18 Jun 2005
- [`2003-04/2-liga2.csv`](2003-04/2-liga2.csv) =>  22 teams,  462 matches,  1024 goals,  42 rounds,  Sat 30 Aug 2003 - Sat 19 Jun 2004
- [`2002-03/2-liga2.csv`](2002-03/2-liga2.csv) =>  22 teams,  462 matches,  1030 goals,  42 rounds,  Sat 31 Aug 2002 - Sun 29 Jun 2003
- [`2001-02/2-liga2.csv`](2001-02/2-liga2.csv) =>  22 teams,  462 matches,  996 goals,  42 rounds,  Sat 25 Aug 2001 - Sat 25 May 2002
- [`2000-01/2-liga2.csv`](2000-01/2-liga2.csv) =>  22 teams,  462 matches,  1016 goals,  42 rounds,  Sat 02 Sep 2000 - Sun 17 Jun 2001
- [`1999-00/2-liga2.csv`](1999-00/2-liga2.csv) =>  22 teams,  462 matches,  1068 goals,  42 rounds,  Sun 22 Aug 1999 - Sun 04 Jun 2000
- [`1998-99/2-liga2.csv`](1998-99/2-liga2.csv) =>  22 teams,  462 matches,  1120 goals,  42 rounds,  Sat 29 Aug 1998 - Sun 20 Jun 1999
- [`1997-98/2-liga2.csv`](1997-98/2-liga2.csv) =>  22 teams,  462 matches,  999 goals,  42 rounds,  Sat 30 Aug 1997 - Sat 16 May 1998
- [`1996-97/2-liga2.csv`](1996-97/2-liga2.csv) =>  20 teams,  380 matches,  908 goals,  38 rounds,  Sat 31 Aug 1996 - Sun 15 Jun 1997


2017-18 - 2 levels (1 2)
  - 1: [`2017-18/1-liga.csv`](2017-18/1-liga.csv) -  20 teams,  380 matches,  1024 goals,  38 rounds,  Fri 18 Aug 2017 - Sun 20 May 2018
    - Athletic Club Bilbao, Atlético Madrid, CD Leganés, Deportivo Alavés, FC Barcelona, Getafe CF, Girona FC, Levante UD, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, Real Betis, Real Madrid CF, Real Sociedad, SD Eibar, Sevilla FC, UD Las Palmas, Valencia CF, Villarreal CF
      - (++) new in season 2017-18: (3) Getafe CF, Girona FC, Levante UD
      - (--) out down: (3) CA Osasuna, Granada CF, Sporting Gijón

  - 2: [`2017-18/2-liga2.csv`](2017-18/2-liga2.csv) -  22 teams,  462 matches,  1066 goals,  42 rounds,  Fri 18 Aug 2017 - Sat 2 Jun 2018
    - AD Alcorcón, Albacete Balompié, CA Osasuna, CD Lugo, CD Numancia, CD Tenerife, CF Reus, Cultural Leonesa, Cádiz CF, Córdoba CF, FC Barcelona B, Gimnàstic Tarragona, Granada CF, Lorca FC, Rayo Vallecano, Real Oviedo, Real Valladolid CF, Real Zaragoza, SD Huesca, Sevilla FC B, Sporting Gijón, UD Almería
      - (++) new in season 2017-18: (7) Albacete Balompié, CA Osasuna, Cultural Leonesa, FC Barcelona B, Granada CF, Lorca FC, Sporting Gijón
      - (--) out up/down: (7) CD Mirandés, Elche CF, Getafe CF, Girona FC, Levante UD, RCD Mallorca, UCAM Murcia

2016-17 - 2 levels (1 2)
  - 1: [`2016-17/1-liga.csv`](2016-17/1-liga.csv) -  20 teams,  380 matches,  1118 goals,  38 rounds,  Fri 19 Aug 2016 - Sun 21 May 2017
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, CD Leganés, Deportivo Alavés, FC Barcelona, Granada CF, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, Real Betis, Real Madrid CF, Real Sociedad, SD Eibar, Sevilla FC, Sporting Gijón, UD Las Palmas, Valencia CF, Villarreal CF
      - (++) new in season 2016-17: (3) CA Osasuna, CD Leganés, Deportivo Alavés
      - (--) out down: (3) Getafe CF, Levante UD, Rayo Vallecano

  - 2: [`2016-17/2-liga2.csv`](2016-17/2-liga2.csv) -  22 teams,  462 matches,  1041 goals,  42 rounds,  Fri 19 Aug 2016 - Sun 11 Jun 2017
    - AD Alcorcón, CD Lugo, CD Mirandés, CD Numancia, CD Tenerife, CF Reus, Cádiz CF, Córdoba CF, Elche CF, Getafe CF, Gimnàstic Tarragona, Girona FC, Levante UD, RCD Mallorca, Rayo Vallecano, Real Oviedo, Real Valladolid CF, Real Zaragoza, SD Huesca, Sevilla FC B, UCAM Murcia, UD Almería
      - (++) new in season 2016-17: (7) CF Reus, Cádiz CF, Getafe CF, Levante UD, Rayo Vallecano, Sevilla FC B, UCAM Murcia
      - (--) out up/down: (7) Albacete Balompié, Athletic Club Bilbao B, CA Osasuna, CD Leganés, Deportivo Alavés, SD Ponferradina, UE Llagostera

2015-16 - 2 levels (1 2)
  - 1: [`2015-16/1-liga.csv`](2015-16/1-liga.csv) -  20 teams,  380 matches,  1043 goals,  38 rounds,  Fri 21 Aug 2015 - Sun 15 May 2016
    - Athletic Club Bilbao, Atlético Madrid, FC Barcelona, Getafe CF, Granada CF, Levante UD, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, Rayo Vallecano, Real Betis, Real Madrid CF, Real Sociedad, SD Eibar, Sevilla FC, Sporting Gijón, UD Las Palmas, Valencia CF, Villarreal CF
      - (++) new in season 2015-16: (3) Real Betis, Sporting Gijón, UD Las Palmas
      - (--) out down: (3) Córdoba CF, Elche CF, UD Almería

  - 2: [`2015-16/2-liga2.csv`](2015-16/2-liga2.csv) -  22 teams,  462 matches,  1043 goals,  42 rounds,  Sat 22 Aug 2015 - Sat 4 Jun 2016
    - AD Alcorcón, Albacete Balompié, Athletic Club Bilbao B, CA Osasuna, CD Leganés, CD Lugo, CD Mirandés, CD Numancia, CD Tenerife, Córdoba CF, Deportivo Alavés, Elche CF, Gimnàstic Tarragona, Girona FC, RCD Mallorca, Real Oviedo, Real Valladolid CF, Real Zaragoza, SD Huesca, SD Ponferradina, UD Almería, UE Llagostera
      - (++) new in season 2015-16: (7) Athletic Club Bilbao B, Córdoba CF, Elche CF, Gimnàstic Tarragona, Real Oviedo, SD Huesca, UD Almería
      - (--) out up/down: (7) CE Sabadell, FC Barcelona B, Real Betis, Real Racing Santander, Recreativo Huelva, Sporting Gijón, UD Las Palmas

2014-15 - 2 levels (1 2)
  - 1: [`2014-15/1-liga.csv`](2014-15/1-liga.csv) -  20 teams,  380 matches,  1009 goals,  38 rounds,  Sat 23 Aug 2014 - Sat 23 May 2015
    - Athletic Club Bilbao, Atlético Madrid, Córdoba CF, Elche CF, FC Barcelona, Getafe CF, Granada CF, Levante UD, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, Rayo Vallecano, Real Madrid CF, Real Sociedad, SD Eibar, Sevilla FC, UD Almería, Valencia CF, Villarreal CF
      - (++) new in season 2014-15: (3) Córdoba CF, RCD La Coruña, SD Eibar
      - (--) out down: (3) CA Osasuna, Real Betis, Real Valladolid CF

  - 2: [`2014-15/2-liga2.csv`](2014-15/2-liga2.csv) -  22 teams,  462 matches,  1136 goals,  42 rounds,  Sat 23 Aug 2014 - Sun 7 Jun 2015
    - AD Alcorcón, Albacete Balompié, CA Osasuna, CD Leganés, CD Lugo, CD Mirandés, CD Numancia, CD Tenerife, CE Sabadell, Deportivo Alavés, FC Barcelona B, Girona FC, RCD Mallorca, Real Betis, Real Racing Santander, Real Valladolid CF, Real Zaragoza, Recreativo Huelva, SD Ponferradina, Sporting Gijón, UD Las Palmas, UE Llagostera
      - (++) new in season 2014-15: (7) Albacete Balompié, CA Osasuna, CD Leganés, Real Betis, Real Racing Santander, Real Valladolid CF, UE Llagostera
      - (--) out up/down: (7) Córdoba CF, Hércules CF, RCD La Coruña, Real Jaén CF, Real Madrid CF B, Real Murcia CF, SD Eibar

2013-14 - 2 levels (1 2)
  - 1: [`2013-14/1-liga.csv`](2013-14/1-liga.csv) -  20 teams,  380 matches,  1045 goals,  38 rounds,  Sat 17 Aug 2013 - Sun 18 May 2014
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, Elche CF, FC Barcelona, Getafe CF, Granada CF, Levante UD, Málaga CF, RC Celta Vigo, RCD Español, Rayo Vallecano, Real Betis, Real Madrid CF, Real Sociedad, Real Valladolid CF, Sevilla FC, UD Almería, Valencia CF, Villarreal CF
      - (++) new in season 2013-14: (3) Elche CF, UD Almería, Villarreal CF
      - (--) out down: (3) RCD La Coruña, RCD Mallorca, Real Zaragoza

  - 2: [`2013-14/2-liga2.csv`](2013-14/2-liga2.csv) -  22 teams,  462 matches,  1078 goals,  42 rounds,  Fri 16 Aug 2013 - Sun 8 Jun 2014
    - AD Alcorcón, CD Lugo, CD Mirandés, CD Numancia, CD Tenerife, CE Sabadell, Córdoba CF, Deportivo Alavés, FC Barcelona B, Girona FC, Hércules CF, RCD La Coruña, RCD Mallorca, Real Jaén CF, Real Madrid CF B, Real Murcia CF, Real Zaragoza, Recreativo Huelva, SD Eibar, SD Ponferradina, Sporting Gijón, UD Las Palmas
      - (++) new in season 2013-14: (7) CD Tenerife, Deportivo Alavés, RCD La Coruña, RCD Mallorca, Real Jaén CF, Real Zaragoza, SD Eibar
      - (--) out up/down: (7) CD Guadalajara, Elche CF, Real Racing Santander, SD Huesca, UD Almería, Villarreal CF, Xerez CD

2012-13 - 2 levels (1 2)
  - 1: [`2012-13/1-liga.csv`](2012-13/1-liga.csv) -  20 teams,  380 matches,  1091 goals,  38 rounds,  Sat 18 Aug 2012 - Sat 1 Jun 2013
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, FC Barcelona, Getafe CF, Granada CF, Levante UD, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, RCD Mallorca, Rayo Vallecano, Real Betis, Real Madrid CF, Real Sociedad, Real Valladolid CF, Real Zaragoza, Sevilla FC, Valencia CF
      - (++) new in season 2012-13: (3) RC Celta Vigo, RCD La Coruña, Real Valladolid CF
      - (--) out down: (3) Real Racing Santander, Sporting Gijón, Villarreal CF

  - 2: [`2012-13/2-liga2.csv`](2012-13/2-liga2.csv) -  22 teams,  462 matches,  1203 goals,  42 rounds,  Fri 17 Aug 2012 - Sun 9 Jun 2013
    - AD Alcorcón, CD Guadalajara, CD Lugo, CD Mirandés, CD Numancia, CE Sabadell, Córdoba CF, Elche CF, FC Barcelona B, Girona FC, Hércules CF, Real Madrid CF B, Real Murcia CF, Real Racing Santander, Recreativo Huelva, SD Huesca, SD Ponferradina, Sporting Gijón, UD Almería, UD Las Palmas, Villarreal CF, Xerez CD
      - (++) new in season 2012-13: (7) CD Lugo, CD Mirandés, Real Madrid CF B, Real Racing Santander, SD Ponferradina, Sporting Gijón, Villarreal CF
      - (--) out up/down: (7) CD Alcoyano, FC Cartagena, Gimnàstic Tarragona, RC Celta Vigo, RCD La Coruña, Real Valladolid CF, Villarreal CF B

2011-12 - 2 levels (1 2)
  - 1: [`2011-12/1-liga.csv`](2011-12/1-liga.csv) -  20 teams,  380 matches,  1050 goals,  38 rounds,  Sat 27 Aug 2011 - Sun 13 May 2012
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, FC Barcelona, Getafe CF, Granada CF, Levante UD, Málaga CF, RCD Español, RCD Mallorca, Rayo Vallecano, Real Betis, Real Madrid CF, Real Racing Santander, Real Sociedad, Real Zaragoza, Sevilla FC, Sporting Gijón, Valencia CF, Villarreal CF
      - (++) new in season 2011-12: (3) Granada CF, Rayo Vallecano, Real Betis
      - (--) out down: (3) Hércules CF, RCD La Coruña, UD Almería

  - 2: [`2011-12/2-liga2.csv`](2011-12/2-liga2.csv) -  22 teams,  462 matches,  1218 goals,  42 rounds,  Fri 26 Aug 2011 - Sun 3 Jun 2012
    - AD Alcorcón, CD Alcoyano, CD Guadalajara, CD Numancia, CE Sabadell, Córdoba CF, Elche CF, FC Barcelona B, FC Cartagena, Gimnàstic Tarragona, Girona FC, Hércules CF, RC Celta Vigo, RCD La Coruña, Real Murcia CF, Real Valladolid CF, Recreativo Huelva, SD Huesca, UD Almería, UD Las Palmas, Villarreal CF B, Xerez CD
      - (++) new in season 2011-12: (7) CD Alcoyano, CD Guadalajara, CE Sabadell, Hércules CF, RCD La Coruña, Real Murcia CF, UD Almería
      - (--) out up/down: (7) Albacete Balompié, CD Tenerife, Granada CF, Rayo Vallecano, Real Betis, SD Ponferradina, UD Salamanca

2010-11 - 2 levels (1 2)
  - 1: [`2010-11/1-liga.csv`](2010-11/1-liga.csv) -  20 teams,  380 matches,  1042 goals,  38 rounds,  Sat 28 Aug 2010 - Sat 21 May 2011
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, FC Barcelona, Getafe CF, Hércules CF, Levante UD, Málaga CF, RCD Español, RCD La Coruña, RCD Mallorca, Real Madrid CF, Real Racing Santander, Real Sociedad, Real Zaragoza, Sevilla FC, Sporting Gijón, UD Almería, Valencia CF, Villarreal CF
      - (++) new in season 2010-11: (3) Hércules CF, Levante UD, Real Sociedad
      - (--) out down: (3) CD Tenerife, Real Valladolid CF, Xerez CD

  - 2: [`2010-11/2-liga2.csv`](2010-11/2-liga2.csv) -  22 teams,  462 matches,  1220 goals,  42 rounds,  Fri 27 Aug 2010 - Sat 4 Jun 2011
    - AD Alcorcón, Albacete Balompié, CD Numancia, CD Tenerife, Córdoba CF, Elche CF, FC Barcelona B, FC Cartagena, Gimnàstic Tarragona, Girona FC, Granada CF, RC Celta Vigo, Rayo Vallecano, Real Betis, Real Valladolid CF, Recreativo Huelva, SD Huesca, SD Ponferradina, UD Las Palmas, UD Salamanca, Villarreal CF B, Xerez CD
      - (++) new in season 2010-11: (7) AD Alcorcón, CD Tenerife, FC Barcelona B, Granada CF, Real Valladolid CF, SD Ponferradina, Xerez CD
      - (--) out up/down: (7) CD Castellón, Cádiz CF, Hércules CF, Levante UD, Real Murcia CF, Real Sociedad, Real Unión

2009-10 - 2 levels (1 2)
  - 1: [`2009-10/1-liga.csv`](2009-10/1-liga.csv) -  20 teams,  380 matches,  1031 goals,  38 rounds,  Sat 29 Aug 2009 - Sun 16 May 2010
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, CD Tenerife, FC Barcelona, Getafe CF, Málaga CF, RCD Español, RCD La Coruña, RCD Mallorca, Real Madrid CF, Real Racing Santander, Real Valladolid CF, Real Zaragoza, Sevilla FC, Sporting Gijón, UD Almería, Valencia CF, Villarreal CF, Xerez CD
      - (++) new in season 2009-10: (3) CD Tenerife, Real Zaragoza, Xerez CD
      - (--) out down: (3) CD Numancia, Real Betis, Recreativo Huelva

  - 2: [`2009-10/2-liga2.csv`](2009-10/2-liga2.csv) -  22 teams,  462 matches,  1114 goals,  42 rounds,  Sat 29 Aug 2009 - Sat 19 Jun 2010
    - Albacete Balompié, CD Castellón, CD Numancia, Cádiz CF, Córdoba CF, Elche CF, FC Cartagena, Gimnàstic Tarragona, Girona FC, Hércules CF, Levante UD, RC Celta Vigo, Rayo Vallecano, Real Betis, Real Murcia CF, Real Sociedad, Real Unión, Recreativo Huelva, SD Huesca, UD Las Palmas, UD Salamanca, Villarreal CF B
      - (++) new in season 2009-10: (7) CD Numancia, Cádiz CF, FC Cartagena, Real Betis, Real Unión, Recreativo Huelva, Villarreal CF B
      - (--) out up/down: (7) Alicante CF, CD Tenerife, Deportivo Alavés, Real Zaragoza, SD Eibar, Sevilla FC B, Xerez CD

2008-09 - 2 levels (1 2)
  - 1: [`2008-09/1-liga.csv`](2008-09/1-liga.csv) -  20 teams,  380 matches,  1101 goals,  38 rounds,  Sat 30 Aug 2008 - Sun 31 May 2009
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, CD Numancia, FC Barcelona, Getafe CF, Málaga CF, RCD Español, RCD La Coruña, RCD Mallorca, Real Betis, Real Madrid CF, Real Racing Santander, Real Valladolid CF, Recreativo Huelva, Sevilla FC, Sporting Gijón, UD Almería, Valencia CF, Villarreal CF
      - (++) new in season 2008-09: (3) CD Numancia, Málaga CF, Sporting Gijón
      - (--) out down: (3) Levante UD, Real Murcia CF, Real Zaragoza

  - 2: [`2008-09/2-liga2.csv`](2008-09/2-liga2.csv) -  22 teams,  462 matches,  1160 goals,  42 rounds,  Sat 30 Aug 2008 - Sun 21 Jun 2009
    - Albacete Balompié, Alicante CF, CD Castellón, CD Tenerife, Córdoba CF, Deportivo Alavés, Elche CF, Gimnàstic Tarragona, Girona FC, Hércules CF, Levante UD, RC Celta Vigo, Rayo Vallecano, Real Murcia CF, Real Sociedad, Real Zaragoza, SD Eibar, SD Huesca, Sevilla FC B, UD Las Palmas, UD Salamanca, Xerez CD
      - (++) new in season 2008-09: (7) Alicante CF, Girona FC, Levante UD, Rayo Vallecano, Real Murcia CF, Real Zaragoza, SD Huesca
      - (--) out up/down: (7) CD Numancia, Cádiz CF, Granada 74, Málaga CF, Polideportivo Ejido, Racing Ferrol, Sporting Gijón

2007-08 - 2 levels (1 2)
  - 1: [`2007-08/1-liga.csv`](2007-08/1-liga.csv) -  20 teams,  380 matches,  1021 goals,  38 rounds,  Sat 25 Aug 2007 - Sun 18 May 2008
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, FC Barcelona, Getafe CF, Levante UD, RCD Español, RCD La Coruña, RCD Mallorca, Real Betis, Real Madrid CF, Real Murcia CF, Real Racing Santander, Real Valladolid CF, Real Zaragoza, Recreativo Huelva, Sevilla FC, UD Almería, Valencia CF, Villarreal CF
      - (++) new in season 2007-08: (3) Real Murcia CF, Real Valladolid CF, UD Almería
      - (--) out down: (3) Gimnàstic Tarragona, RC Celta Vigo, Real Sociedad

  - 2: [`2007-08/2-liga2.csv`](2007-08/2-liga2.csv) -  22 teams,  462 matches,  1072 goals,  42 rounds,  Sat 25 Aug 2007 - Sun 15 Jun 2008
    - Albacete Balompié, CD Castellón, CD Numancia, CD Tenerife, Cádiz CF, Córdoba CF, Deportivo Alavés, Elche CF, Gimnàstic Tarragona, Granada 74, Hércules CF, Málaga CF, Polideportivo Ejido, RC Celta Vigo, Racing Ferrol, Real Sociedad, SD Eibar, Sevilla FC B, Sporting Gijón, UD Las Palmas, UD Salamanca, Xerez CD
      - (++) new in season 2007-08: (8) Córdoba CF, Gimnàstic Tarragona, Granada 74, RC Celta Vigo, Racing Ferrol, Real Sociedad, SD Eibar, Sevilla FC B
      - (--) out up/down: (8) CF Ciudad de Murcia, Lorca FC, Real Madrid CF B, Real Murcia CF, Real Valladolid CF, SD Ponferradina, UD Almería, UD Vecindario

2006-07 - 2 levels (1 2)
  - 1: [`2006-07/1-liga.csv`](2006-07/1-liga.csv) -  20 teams,  380 matches,  942 goals,  38 rounds,  Sat 26 Aug 2006 - Sun 17 Jun 2007
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, FC Barcelona, Getafe CF, Gimnàstic Tarragona, Levante UD, RC Celta Vigo, RCD Español, RCD La Coruña, RCD Mallorca, Real Betis, Real Madrid CF, Real Racing Santander, Real Sociedad, Real Zaragoza, Recreativo Huelva, Sevilla FC, Valencia CF, Villarreal CF
      - (++) new in season 2006-07: (3) Gimnàstic Tarragona, Levante UD, Recreativo Huelva
      - (--) out down: (3) Cádiz CF, Deportivo Alavés, Málaga CF

  - 2: [`2006-07/2-liga2.csv`](2006-07/2-liga2.csv) -  22 teams,  462 matches,  1133 goals,  42 rounds,  Sat 26 Aug 2006 - Sun 17 Jun 2007
    - Albacete Balompié, CD Castellón, CD Numancia, CD Tenerife, CF Ciudad de Murcia, Cádiz CF, Deportivo Alavés, Elche CF, Hércules CF, Lorca FC, Málaga CF, Polideportivo Ejido, Real Madrid CF B, Real Murcia CF, Real Valladolid CF, SD Ponferradina, Sporting Gijón, UD Almería, UD Las Palmas, UD Salamanca, UD Vecindario, Xerez CD
      - (++) new in season 2006-07: (7) Cádiz CF, Deportivo Alavés, Málaga CF, SD Ponferradina, UD Las Palmas, UD Salamanca, UD Vecindario
      - (--) out up/down: (7) Gimnàstic Tarragona, Levante UD, Málaga CF B, Racing Ferrol, Recreativo Huelva, SD Eibar, UE Lleida

2005-06 - 2 levels (1 2)
  - 1: [`2005-06/1-liga.csv`](2005-06/1-liga.csv) -  20 teams,  380 matches,  936 goals,  38 rounds,  Sat 27 Aug 2005 - Sat 20 May 2006
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, Cádiz CF, Deportivo Alavés, FC Barcelona, Getafe CF, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, RCD Mallorca, Real Betis, Real Madrid CF, Real Racing Santander, Real Sociedad, Real Zaragoza, Sevilla FC, Valencia CF, Villarreal CF
      - (++) new in season 2005-06: (3) Cádiz CF, Deportivo Alavés, RC Celta Vigo
      - (--) out down: (3) Albacete Balompié, CD Numancia, Levante UD

  - 2: [`2005-06/2-liga2.csv`](2005-06/2-liga2.csv) -  22 teams,  462 matches,  1061 goals,  42 rounds,  Sat 27 Aug 2005 - Sun 18 Jun 2006
    - Albacete Balompié, CD Castellón, CD Numancia, CD Tenerife, CF Ciudad de Murcia, Elche CF, Gimnàstic Tarragona, Hércules CF, Levante UD, Lorca FC, Málaga CF B, Polideportivo Ejido, Racing Ferrol, Real Madrid CF B, Real Murcia CF, Real Valladolid CF, Recreativo Huelva, SD Eibar, Sporting Gijón, UD Almería, UE Lleida, Xerez CD
      - (++) new in season 2005-06: (7) Albacete Balompié, CD Castellón, CD Numancia, Hércules CF, Levante UD, Lorca FC, Real Madrid CF B
      - (--) out up/down: (7) Cádiz CF, Córdoba CF, Deportivo Alavés, Pontevedra CF, RC Celta Vigo, Terrassa FC, UD Salamanca

2004-05 - 2 levels (1 2)
  - 1: [`2004-05/1-liga.csv`](2004-05/1-liga.csv) -  20 teams,  380 matches,  980 goals,  38 rounds,  Sat 28 Aug 2004 - Sun 29 May 2005
    - Albacete Balompié, Athletic Club Bilbao, Atlético Madrid, CA Osasuna, CD Numancia, FC Barcelona, Getafe CF, Levante UD, Málaga CF, RCD Español, RCD La Coruña, RCD Mallorca, Real Betis, Real Madrid CF, Real Racing Santander, Real Sociedad, Real Zaragoza, Sevilla FC, Valencia CF, Villarreal CF
      - (++) new in season 2004-05: (3) CD Numancia, Getafe CF, Levante UD
      - (--) out down: (3) RC Celta Vigo, Real Murcia CF, Real Valladolid CF

  - 2: [`2004-05/2-liga2.csv`](2004-05/2-liga2.csv) -  22 teams,  462 matches,  1055 goals,  42 rounds,  Sat 28 Aug 2004 - Sat 18 Jun 2005
    - CD Tenerife, CF Ciudad de Murcia, Cádiz CF, Córdoba CF, Deportivo Alavés, Elche CF, Gimnàstic Tarragona, Málaga CF B, Polideportivo Ejido, Pontevedra CF, RC Celta Vigo, Racing Ferrol, Real Murcia CF, Real Valladolid CF, Recreativo Huelva, SD Eibar, Sporting Gijón, Terrassa FC, UD Almería, UD Salamanca, UE Lleida, Xerez CD
      - (++) new in season 2004-05: (7) Gimnàstic Tarragona, Pontevedra CF, RC Celta Vigo, Racing Ferrol, Real Murcia CF, Real Valladolid CF, UE Lleida
      - (--) out up/down: (7) Algeciras CF, CD Leganés, CD Numancia, Getafe CF, Levante UD, Rayo Vallecano, UD Las Palmas

2003-04 - 2 levels (1 2)
  - 1: [`2003-04/1-liga.csv`](2003-04/1-liga.csv) -  20 teams,  380 matches,  1015 goals,  38 rounds,  Sat 30 Aug 2003 - Sun 23 May 2004
    - Albacete Balompié, Athletic Club Bilbao, Atlético Madrid, CA Osasuna, FC Barcelona, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, RCD Mallorca, Real Betis, Real Madrid CF, Real Murcia CF, Real Racing Santander, Real Sociedad, Real Valladolid CF, Real Zaragoza, Sevilla FC, Valencia CF, Villarreal CF
      - (++) new in season 2003-04: (3) Albacete Balompié, Real Murcia CF, Real Zaragoza
      - (--) out down: (3) Deportivo Alavés, Rayo Vallecano, Recreativo Huelva

  - 2: [`2003-04/2-liga2.csv`](2003-04/2-liga2.csv) -  22 teams,  462 matches,  1024 goals,  42 rounds,  Sat 30 Aug 2003 - Sat 19 Jun 2004
    - Algeciras CF, CD Leganés, CD Numancia, CD Tenerife, CF Ciudad de Murcia, Cádiz CF, Córdoba CF, Deportivo Alavés, Elche CF, Getafe CF, Levante UD, Málaga CF B, Polideportivo Ejido, Rayo Vallecano, Recreativo Huelva, SD Eibar, Sporting Gijón, Terrassa FC, UD Almería, UD Las Palmas, UD Salamanca, Xerez CD
      - (++) new in season 2003-04: (7) Algeciras CF, CF Ciudad de Murcia, Cádiz CF, Deportivo Alavés, Málaga CF B, Rayo Vallecano, Recreativo Huelva
      - (--) out up/down: (7) Albacete Balompié, CD Badajoz, Racing Ferrol, Real Murcia CF, Real Oviedo, Real Zaragoza, SD Compostela

2002-03 - 2 levels (1 2)
  - 1: [`2002-03/1-liga.csv`](2002-03/1-liga.csv) -  20 teams,  380 matches,  1016 goals,  38 rounds,  Sat 31 Aug 2002 - Sun 22 Jun 2003
    - Athletic Club Bilbao, Atlético Madrid, CA Osasuna, Deportivo Alavés, FC Barcelona, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, RCD Mallorca, Rayo Vallecano, Real Betis, Real Madrid CF, Real Racing Santander, Real Sociedad, Real Valladolid CF, Recreativo Huelva, Sevilla FC, Valencia CF, Villarreal CF
      - (++) new in season 2002-03: (3) Atlético Madrid, Real Racing Santander, Recreativo Huelva
      - (--) out down: (3) CD Tenerife, Real Zaragoza, UD Las Palmas

  - 2: [`2002-03/2-liga2.csv`](2002-03/2-liga2.csv) -  22 teams,  462 matches,  1030 goals,  42 rounds,  Sat 31 Aug 2002 - Sun 29 Jun 2003
    - Albacete Balompié, CD Badajoz, CD Leganés, CD Numancia, CD Tenerife, Córdoba CF, Elche CF, Getafe CF, Levante UD, Polideportivo Ejido, Racing Ferrol, Real Murcia CF, Real Oviedo, Real Zaragoza, SD Compostela, SD Eibar, Sporting Gijón, Terrassa FC, UD Almería, UD Las Palmas, UD Salamanca, Xerez CD
      - (++) new in season 2002-03: (7) CD Tenerife, Getafe CF, Real Zaragoza, SD Compostela, Terrassa FC, UD Almería, UD Las Palmas
      - (--) out up/down: (7) Atlético Madrid, Burgos CF, CF Extremadura, Gimnàstic Tarragona, Real Jaén CF, Real Racing Santander, Recreativo Huelva

2001-02 - 2 levels (1 2)
  - 1: [`2001-02/1-liga.csv`](2001-02/1-liga.csv) -  20 teams,  380 matches,  961 goals,  38 rounds,  Sat 25 Aug 2001 - Sat 11 May 2002
    - Athletic Club Bilbao, CA Osasuna, CD Tenerife, Deportivo Alavés, FC Barcelona, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, RCD Mallorca, Rayo Vallecano, Real Betis, Real Madrid CF, Real Sociedad, Real Valladolid CF, Real Zaragoza, Sevilla FC, UD Las Palmas, Valencia CF, Villarreal CF
      - (++) new in season 2001-02: (3) CD Tenerife, Real Betis, Sevilla FC
      - (--) out down: (3) CD Numancia, Real Oviedo, Real Racing Santander

  - 2: [`2001-02/2-liga2.csv`](2001-02/2-liga2.csv) -  22 teams,  462 matches,  996 goals,  42 rounds,  Sat 25 Aug 2001 - Sat 25 May 2002
    - Albacete Balompié, Atlético Madrid, Burgos CF, CD Badajoz, CD Leganés, CD Numancia, CF Extremadura, Córdoba CF, Elche CF, Gimnàstic Tarragona, Levante UD, Polideportivo Ejido, Racing Ferrol, Real Jaén CF, Real Murcia CF, Real Oviedo, Real Racing Santander, Recreativo Huelva, SD Eibar, Sporting Gijón, UD Salamanca, Xerez CD
      - (++) new in season 2001-02: (7) Burgos CF, CD Numancia, Gimnàstic Tarragona, Polideportivo Ejido, Real Oviedo, Real Racing Santander, Xerez CD
      - (--) out up/down: (7) CD Tenerife, Getafe CF, Real Betis, SD Compostela, Sevilla FC, UE Lleida, Universidad Las Palmas

2000-01 - 2 levels (1 2)
  - 1: [`2000-01/1-liga.csv`](2000-01/1-liga.csv) -  20 teams,  380 matches,  1095 goals,  38 rounds,  Sat 9 Sep 2000 - Sun 17 Jun 2001
    - Athletic Club Bilbao, CA Osasuna, CD Numancia, Deportivo Alavés, FC Barcelona, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, RCD Mallorca, Rayo Vallecano, Real Madrid CF, Real Oviedo, Real Racing Santander, Real Sociedad, Real Valladolid CF, Real Zaragoza, UD Las Palmas, Valencia CF, Villarreal CF
      - (++) new in season 2000-01: (3) CA Osasuna, UD Las Palmas, Villarreal CF
      - (--) out down: (3) Atlético Madrid, Real Betis, Sevilla FC

  - 2: [`2000-01/2-liga2.csv`](2000-01/2-liga2.csv) -  22 teams,  462 matches,  1016 goals,  42 rounds,  Sat 2 Sep 2000 - Sun 17 Jun 2001
    - Albacete Balompié, Atlético Madrid, CD Badajoz, CD Leganés, CD Tenerife, CF Extremadura, Córdoba CF, Elche CF, Getafe CF, Levante UD, Racing Ferrol, Real Betis, Real Jaén CF, Real Murcia CF, Recreativo Huelva, SD Compostela, SD Eibar, Sevilla FC, Sporting Gijón, UD Salamanca, UE Lleida, Universidad Las Palmas
      - (++) new in season 2000-01: (7) Atlético Madrid, Racing Ferrol, Real Betis, Real Jaén CF, Real Murcia CF, Sevilla FC, Universidad Las Palmas
      - (--) out up/down: (7) Atlético Madrid B, CA Osasuna, CD Logroñés, CD Toledo, CP Mérida, UD Las Palmas, Villarreal CF

1999-00 - 2 levels (1 2)
  - 1: [`1999-00/1-liga.csv`](1999-00/1-liga.csv) -  20 teams,  380 matches,  999 goals,  38 rounds,  Sat 21 Aug 1999 - Sat 20 May 2000
    - Athletic Club Bilbao, Atlético Madrid, CD Numancia, Deportivo Alavés, FC Barcelona, Málaga CF, RC Celta Vigo, RCD Español, RCD La Coruña, RCD Mallorca, Rayo Vallecano, Real Betis, Real Madrid CF, Real Oviedo, Real Racing Santander, Real Sociedad, Real Valladolid CF, Real Zaragoza, Sevilla FC, Valencia CF
      - (++) new in season 1999-00: (4) CD Numancia, Málaga CF, Rayo Vallecano, Sevilla FC
      - (--) out down: (4) CD Tenerife, CF Extremadura, UD Salamanca, Villarreal CF

  - 2: [`1999-00/2-liga2.csv`](1999-00/2-liga2.csv) -  22 teams,  462 matches,  1068 goals,  42 rounds,  Sun 22 Aug 1999 - Sun 4 Jun 2000
    - Albacete Balompié, Atlético Madrid B, CA Osasuna, CD Badajoz, CD Leganés, CD Logroñés, CD Tenerife, CD Toledo, CF Extremadura, CP Mérida, Córdoba CF, Elche CF, Getafe CF, Levante UD, Recreativo Huelva, SD Compostela, SD Eibar, Sporting Gijón, UD Las Palmas, UD Salamanca, UE Lleida, Villarreal CF
      - (++) new in season 1999-00: (8) CD Tenerife, CF Extremadura, Córdoba CF, Elche CF, Getafe CF, Levante UD, UD Salamanca, Villarreal CF
      - (--) out up/down: (8) CD Numancia, CD Ourense, FC Barcelona B, Hércules CF, Málaga CF, RCD Mallorca B, Rayo Vallecano, Sevilla FC

1998-99 - 2 levels (1 2)
  - 1: [`1998-99/1-liga.csv`](1998-99/1-liga.csv) -  20 teams,  380 matches,  1003 goals,  38 rounds,  Sat 29 Aug 1998 - Sun 20 Jun 1999
    - Athletic Club Bilbao, Atlético Madrid, CD Tenerife, CF Extremadura, Deportivo Alavés, FC Barcelona, RC Celta Vigo, RCD Español, RCD La Coruña, RCD Mallorca, Real Betis, Real Madrid CF, Real Oviedo, Real Racing Santander, Real Sociedad, Real Valladolid CF, Real Zaragoza, UD Salamanca, Valencia CF, Villarreal CF
      - (++) new in season 1998-99: (3) CF Extremadura, Deportivo Alavés, Villarreal CF
      - (--) out down: (3) CP Mérida, SD Compostela, Sporting Gijón

  - 2: [`1998-99/2-liga2.csv`](1998-99/2-liga2.csv) -  22 teams,  462 matches,  1120 goals,  42 rounds,  Sat 29 Aug 1998 - Sun 20 Jun 1999
    - Albacete Balompié, Atlético Madrid B, CA Osasuna, CD Badajoz, CD Leganés, CD Logroñés, CD Numancia, CD Ourense, CD Toledo, CP Mérida, FC Barcelona B, Hércules CF, Málaga CF, RCD Mallorca B, Rayo Vallecano, Recreativo Huelva, SD Compostela, SD Eibar, Sevilla FC, Sporting Gijón, UD Las Palmas, UE Lleida
      - (++) new in season 1998-99: (7) CP Mérida, FC Barcelona B, Málaga CF, RCD Mallorca B, Recreativo Huelva, SD Compostela, Sporting Gijón
      - (--) out up/down: (7) CF Extremadura, Deportivo Alavés, Elche CF, Levante UD, Real Jaén CF, Villarreal CF, Xerez CD

1997-98 - 2 levels (1 2)
  - 1: [`1997-98/1-liga.csv`](1997-98/1-liga.csv) -  20 teams,  380 matches,  1009 goals,  38 rounds,  Sat 30 Aug 1997 - Sat 16 May 1998
    - Athletic Club Bilbao, Atlético Madrid, CD Tenerife, CP Mérida, FC Barcelona, RC Celta Vigo, RCD Español, RCD La Coruña, RCD Mallorca, Real Betis, Real Madrid CF, Real Oviedo, Real Racing Santander, Real Sociedad, Real Valladolid CF, Real Zaragoza, SD Compostela, Sporting Gijón, UD Salamanca, Valencia CF
      - (++) new in season 1997-98: (3) CP Mérida, RCD Mallorca, UD Salamanca
      - (--) out down: (5) CD Logroñés, CF Extremadura, Hércules CF, Rayo Vallecano, Sevilla FC

  - 2: [`1997-98/2-liga2.csv`](1997-98/2-liga2.csv) -  22 teams,  462 matches,  999 goals,  42 rounds,  Sat 30 Aug 1997 - Sat 16 May 1998
    - Albacete Balompié, Atlético Madrid B, CA Osasuna, CD Badajoz, CD Leganés, CD Logroñés, CD Numancia, CD Ourense, CD Toledo, CF Extremadura, Deportivo Alavés, Elche CF, Hércules CF, Levante UD, Rayo Vallecano, Real Jaén CF, SD Eibar, Sevilla FC, UD Las Palmas, UE Lleida, Villarreal CF, Xerez CD
      - (++) new in season 1997-98: (9) CD Logroñés, CD Numancia, CF Extremadura, Elche CF, Hércules CF, Rayo Vallecano, Real Jaén CF, Sevilla FC, Xerez CD
      - (--) out up/down: (7) CP Mérida, FC Barcelona B, RCD Mallorca, Real Madrid CF B, UD Almería, UD Salamanca, Écija Balompié

1996-97 - 2 levels (1 2)
  - 1: [`1996-97/1-liga.csv`](1996-97/1-liga.csv) -  22 teams,  462 matches,  1271 goals,  42 rounds,  Sat 31 Aug 1996 - Mon 23 Jun 1997
    - Athletic Club Bilbao, Atlético Madrid, CD Logroñés, CD Tenerife, CF Extremadura, FC Barcelona, Hércules CF, RC Celta Vigo, RCD Español, RCD La Coruña, Rayo Vallecano, Real Betis, Real Madrid CF, Real Oviedo, Real Racing Santander, Real Sociedad, Real Valladolid CF, Real Zaragoza, SD Compostela, Sevilla FC, Sporting Gijón, Valencia CF
      - (++) new in season 1996-97: (3) CD Logroñés, CF Extremadura, Hércules CF
      - (--) out down: (3) Albacete Balompié, CP Mérida, UD Salamanca

  - 2: [`1996-97/2-liga2.csv`](1996-97/2-liga2.csv) -  20 teams,  380 matches,  908 goals,  38 rounds,  Sat 31 Aug 1996 - Sun 15 Jun 1997
    - Albacete Balompié, Atlético Madrid B, CA Osasuna, CD Badajoz, CD Leganés, CD Ourense, CD Toledo, CP Mérida, Deportivo Alavés, FC Barcelona B, Levante UD, RCD Mallorca, Real Madrid CF B, SD Eibar, UD Almería, UD Las Palmas, UD Salamanca, UE Lleida, Villarreal CF, Écija Balompié




## Teams

```
  87 teams:
    [1]  AD Alcorcón                     ::  336 matches in   8 seasons / 1 levels -    x      2 (8)     
    [2]  Albacete Balompié               ::  862 matches in  21 seasons / 2 levels - 1 (5)     2 (16)    
    [3]  Algeciras CF                    ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
    [4]  Alicante CF                     ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
    [5]  Athletic Club Bilbao            ::  958 matches in  25 seasons / 1 levels - 1 (25)       x      
    [6]  Athletic Club Bilbao B          ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
    [7]  Atlético Madrid                 ::  966 matches in  25 seasons / 2 levels - 1 (23)    2 (2)     
    [8]  Atlético Madrid B               ::  164 matches in   4 seasons / 1 levels -    x      2 (4)     
    [9]  Burgos CF                       ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
   [10]  CA Osasuna                      ::  898 matches in  23 seasons / 2 levels - 1 (16)    2 (7)     
   [11]  CD Alcoyano                     ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
   [12]  CD Badajoz                      ::  290 matches in   7 seasons / 1 levels -    x      2 (7)     
   [13]  CD Castellón                    ::  210 matches in   5 seasons / 1 levels -    x      2 (5)     
   [14]  CD Guadalajara                  ::   84 matches in   2 seasons / 1 levels -    x      2 (2)     
   [15]  CD Leganés                      ::  492 matches in  12 seasons / 2 levels - 1 (2)     2 (10)    
   [16]  CD Logroñés                     ::  244 matches in   6 seasons / 2 levels - 1 (3)     2 (3)     
   [17]  CD Lugo                         ::  252 matches in   6 seasons / 1 levels -    x      2 (6)     
   [18]  CD Mirandés                     ::  210 matches in   5 seasons / 1 levels -    x      2 (5)     
   [19]  CD Numancia                     ::  866 matches in  21 seasons / 2 levels - 1 (4)     2 (17)    
   [20]  CD Ourense                      ::  122 matches in   3 seasons / 1 levels -    x      2 (3)     
   [21]  CD Tenerife                     ::  942 matches in  23 seasons / 2 levels - 1 (8)     2 (15)    
   [22]  CD Toledo                       ::  164 matches in   4 seasons / 1 levels -    x      2 (4)     
   [23]  CE Sabadell                     ::  168 matches in   4 seasons / 1 levels -    x      2 (4)     
   [24]  CF Ciudad de Murcia             ::  168 matches in   4 seasons / 1 levels -    x      2 (4)     
   [25]  CF Extremadura                  ::  248 matches in   6 seasons / 2 levels - 1 (2)     2 (4)     
   [26]  CF Reus                         ::   84 matches in   2 seasons / 1 levels -    x      2 (2)     
   [27]  CP Mérida                       ::  202 matches in   5 seasons / 2 levels - 1 (2)     2 (3)     
   [28]  Cultural Leonesa                ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
   [29]  Cádiz CF                        ::  332 matches in   8 seasons / 2 levels - 1 (1)     2 (7)     
   [30]  Córdoba CF                      ::  710 matches in  17 seasons / 2 levels - 1 (1)     2 (16)    
   [31]  Deportivo Alavés                ::  720 matches in  18 seasons / 2 levels - 1 (8)     2 (10)    
   [32]  Elche CF                        ::  790 matches in  19 seasons / 2 levels - 1 (2)     2 (17)    
   [33]  FC Barcelona                    ::  958 matches in  25 seasons / 1 levels - 1 (25)       x      
   [34]  FC Barcelona B                  ::  332 matches in   8 seasons / 1 levels -    x      2 (8)     
   [35]  FC Cartagena                    ::  126 matches in   3 seasons / 1 levels -    x      2 (3)     
   [36]  Getafe CF                       ::  704 matches in  18 seasons / 2 levels - 1 (13)    2 (5)     
   [37]  Gimnàstic Tarragona             ::  500 matches in  12 seasons / 2 levels - 1 (1)     2 (11)    
   [38]  Girona FC                       ::  416 matches in  10 seasons / 2 levels - 1 (1)     2 (9)     
   [39]  Granada 74                      ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
   [40]  Granada CF                      ::  312 matches in   8 seasons / 2 levels - 1 (6)     2 (2)     
   [41]  Hércules CF                     ::  500 matches in  12 seasons / 2 levels - 1 (2)     2 (10)    
   [42]  Levante UD                      ::  838 matches in  21 seasons / 2 levels - 1 (10)    2 (11)    
   [43]  Lorca FC                        ::  126 matches in   3 seasons / 1 levels -    x      2 (3)     
   [44]  Málaga CF                       ::  772 matches in  20 seasons / 2 levels - 1 (17)    2 (3)     
   [45]  Málaga CF B                     ::  126 matches in   3 seasons / 1 levels -    x      2 (3)     
   [46]  Polideportivo Ejido             ::  294 matches in   7 seasons / 1 levels -    x      2 (7)     
   [47]  Pontevedra CF                   ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
   [48]  RC Celta Vigo                   ::  982 matches in  25 seasons / 2 levels - 1 (19)    2 (6)     
   [49]  RCD Español                     ::  920 matches in  24 seasons / 1 levels - 1 (24)       x      
   [50]  RCD La Coruña                   ::  966 matches in  25 seasons / 2 levels - 1 (23)    2 (2)     
   [51]  RCD Mallorca                    ::  814 matches in  21 seasons / 2 levels - 1 (16)    2 (5)     
   [52]  RCD Mallorca B                  ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
   [53]  Racing Ferrol                   ::  252 matches in   6 seasons / 1 levels -    x      2 (6)     
   [54]  Rayo Vallecano                  ::  800 matches in  20 seasons / 2 levels - 1 (12)    2 (8)     
   [55]  Real Betis                      ::  936 matches in  24 seasons / 2 levels - 1 (20)    2 (4)     
   [56]  Real Jaén CF                    ::  168 matches in   4 seasons / 1 levels -    x      2 (4)     
   [57]  Real Madrid CF                  ::  958 matches in  25 seasons / 1 levels - 1 (25)       x      
   [58]  Real Madrid CF B                ::  206 matches in   5 seasons / 1 levels -    x      2 (5)     
   [59]  Real Murcia CF                  ::  538 matches in  13 seasons / 2 levels - 1 (2)     2 (11)    
   [60]  Real Oviedo                     ::  522 matches in  13 seasons / 2 levels - 1 (8)     2 (5)     
   [61]  Real Racing Santander           ::  818 matches in  21 seasons / 2 levels - 1 (18)    2 (3)     
   [62]  Real Sociedad                   ::  970 matches in  25 seasons / 2 levels - 1 (22)    2 (3)     
   [63]  Real Unión                      ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
   [64]  Real Valladolid CF              ::  994 matches in  25 seasons / 2 levels - 1 (16)    2 (9)     
   [65]  Real Zaragoza                   ::  986 matches in  25 seasons / 2 levels - 1 (18)    2 (7)     
   [66]  Recreativo Huelva               ::  698 matches in  17 seasons / 2 levels - 1 (4)     2 (13)    
   [67]  SD Compostela                   ::  328 matches in   8 seasons / 2 levels - 1 (4)     2 (4)     
   [68]  SD Eibar                        ::  694 matches in  17 seasons / 2 levels - 1 (4)     2 (13)    
   [69]  SD Huesca                       ::  336 matches in   8 seasons / 1 levels -    x      2 (8)     
   [70]  SD Ponferradina                 ::  252 matches in   6 seasons / 1 levels -    x      2 (6)     
   [71]  Sevilla FC                      ::  970 matches in  25 seasons / 2 levels - 1 (22)    2 (3)     
   [72]  Sevilla FC B                    ::  168 matches in   4 seasons / 1 levels -    x      2 (4)     
   [73]  Sporting Gijón                  :: 1014 matches in  25 seasons / 2 levels - 1 (11)    2 (14)    
   [74]  Terrassa FC                     ::  126 matches in   3 seasons / 1 levels -    x      2 (3)     
   [75]  UCAM Murcia                     ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
   [76]  UD Almería                      ::  686 matches in  17 seasons / 2 levels - 1 (6)     2 (11)    
   [77]  UD Las Palmas                   ::  816 matches in  20 seasons / 2 levels - 1 (5)     2 (15)    
   [78]  UD Salamanca                    ::  618 matches in  15 seasons / 2 levels - 1 (3)     2 (12)    
   [79]  UD Vecindario                   ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
   [80]  UE Llagostera                   ::   84 matches in   2 seasons / 1 levels -    x      2 (2)     
   [81]  UE Lleida                       ::  328 matches in   8 seasons / 2 levels - 1 (1)     2 (7)     
   [82]  Universidad Las Palmas          ::   42 matches in   1 seasons / 1 levels -    x      2 (1)     
   [83]  Valencia CF                     ::  958 matches in  25 seasons / 1 levels - 1 (25)       x      
   [84]  Villarreal CF                   ::  848 matches in  22 seasons / 2 levels - 1 (18)    2 (4)     
   [85]  Villarreal CF B                 ::  126 matches in   3 seasons / 1 levels -    x      2 (3)     
   [86]  Xerez CD                        ::  542 matches in  13 seasons / 2 levels - 1 (1)     2 (12)    
   [87]  Écija Balompié                  ::   38 matches in   1 seasons / 1 levels -    x      2 (1)     
```


### Team Name Mappings



```
AD Alcorcón                 => Alcorcon
Albacete Balompié           => Albacete
Algeciras CF                => Algeciras
Alicante CF                 => Alicante
Athletic Club Bilbao        => Ath Bilbao
Athletic Club Bilbao B      => Ath Bilbao B
Atlético Madrid             => Ath Madrid
Atlético Madrid B           => Ath Madrid B
Burgos CF                   => Burgos
CA Osasuna                  => Osasuna
CD Alcoyano                 => Alcoyano
CD Badajoz                  => Badajoz
CD Castellón                => Castellon
CD Guadalajara              => Guadalajara
CD Leganés                  => Leganes
CD Logroñés                 => Logrones
CD Lugo                     => Lugo
CD Mirandés                 => Mirandes
CD Numancia                 => Numancia
CD Ourense                  => (2) Orense • Ourense
CD Tenerife                 => Tenerife
CD Toledo                   => Toledo
CE Sabadell                 => Sabadell
CF Ciudad de Murcia         => Ciudad de Murcia
CF Extremadura              => Extremadura
CF Reus                     => Reus Deportiu
CP Mérida                   => Merida
Cultural Leonesa            => Leonesa
Cádiz CF                    => Cadiz
Córdoba CF                  => Cordoba
Deportivo Alavés            => Alaves
Elche CF                    => Elche
FC Barcelona                => Barcelona
FC Barcelona B              => Barcelona B
FC Cartagena                => Cartagena
Getafe CF                   => Getafe
Gimnàstic Tarragona         => Gimnastic
Girona FC                   => Girona
Granada 74                  
Granada CF                  => Granada
Hércules CF                 => Hercules
Levante UD                  => Levante
Lorca FC                    => Lorca
Málaga CF                   => Malaga
Málaga CF B                 => Malaga B
Polideportivo Ejido         => Poli Ejido
Pontevedra CF               => Pontevedra
RC Celta Vigo               => Celta
RCD Español                 => Espanol
RCD La Coruña               => La Coruna
RCD Mallorca                => Mallorca
RCD Mallorca B              => Mallorca B
Racing Ferrol               => Ferrol
Rayo Vallecano              => Vallecano
Real Betis                  => Betis
Real Jaén CF                => Jaen
Real Madrid CF              => Real Madrid
Real Madrid CF B            => Real Madrid B
Real Murcia CF              => Murcia
Real Oviedo                 => Oviedo
Real Racing Santander       => Santander
Real Sociedad               => Sociedad
Real Unión                  => Real Union
Real Valladolid CF          => Valladolid
Real Zaragoza               => Zaragoza
Recreativo Huelva           => Recreativo
SD Compostela               => Compostela
SD Eibar                    => Eibar
SD Huesca                   => Huesca
SD Ponferradina             => Ponferradina
Sevilla FC                  => Sevilla
Sevilla FC B                => Sevilla B
Sporting Gijón              => Sp Gijon
Terrassa FC                 => Terrassa
UCAM Murcia                 
UD Almería                  => Almeria
UD Las Palmas               => Las Palmas
UD Salamanca                => Salamanca
UD Vecindario               => Vecindario
UE Llagostera               => Llagostera
UE Lleida                   => (2) Lerida • Lleida
Universidad Las Palmas      => U.Las Palmas
Valencia CF                 => Valencia
Villarreal CF               => (2) Villareal • Villarreal
Villarreal CF B             => Villarreal B
Xerez CD                    => Xerez
Écija Balompié              => Ecija
```



### Teams by City

- ? (27): 
  - CA Osasuna  (1) Osasuna
  - CD Leganés  (1) Leganes
  - CD Logroñés  (1) Logrones
  - CD Lugo  (1) Lugo
  - CD Numancia  (1) Numancia
  - CD Ourense  (2) Ourense • Orense
  - CD Tenerife  (1) Tenerife
  - CD Toledo  (1) Toledo
  - CE Sabadell  (1) Sabadell
  - CF Reus  (1) Reus Deportiu
  - Cultural Leonesa  (1) Leonesa
  - Lorca FC  (1) Lorca
  - Polideportivo Ejido  (1) Poli Ejido
  - Pontevedra CF  (1) Pontevedra
  - Real Oviedo  (1) Oviedo
  - Real Racing Santander  (1) Santander
  - Real Unión  (1) Real Union
  - Real Valladolid CF  (1) Valladolid
  - Real Zaragoza  (1) Zaragoza
  - Recreativo Huelva  (1) Recreativo
  - SD Ponferradina  (1) Ponferradina
  - Terrassa FC  (1) Terrassa
  - UD Salamanca  (1) Salamanca
  - UD Vecindario  (1) Vecindario
  - UE Llagostera  (1) Llagostera
  - UE Lleida  (2) Lerida • Lleida
  - Xerez CD  (1) Xerez
- **Madrid › Comunidad de Madrid** (6): 
  - Atlético Madrid  (1) Ath Madrid
  - Atlético Madrid B  (1) Ath Madrid B
  - Getafe CF  (1) Getafe
  - Rayo Vallecano  (1) Vallecano
  - Real Madrid CF  (1) Real Madrid
  - Real Madrid CF B  (1) Real Madrid B
- **Barcelona › Cataluña** (3): 
  - FC Barcelona  (1) Barcelona
  - FC Barcelona B  (1) Barcelona B
  - RCD Español  (1) Espanol
- **Murcia › Región de Murcia** (3): 
  - CF Ciudad de Murcia  (1) Ciudad de Murcia
  - Real Murcia CF  (1) Murcia
  - UCAM Murcia 
- **Sevilla › Andalucía** (3): 
  - Real Betis  (1) Betis
  - Sevilla FC  (1) Sevilla
  - Sevilla FC B  (1) Sevilla B
- **Alicante › Comunidad Valenciana** (2): 
  - Alicante CF  (1) Alicante
  - Hércules CF  (1) Hercules
- **Bilbao › País Vasco** (2): 
  - Athletic Club Bilbao  (1) Ath Bilbao
  - Athletic Club Bilbao B  (1) Ath Bilbao B
- **Granada › Andalucía** (2): 
  - Granada 74 
  - Granada CF  (1) Granada
- **Las Palmas › Islas Canarias** (2): 
  - UD Las Palmas  (1) Las Palmas
  - Universidad Las Palmas  (1) U.Las Palmas
- **Málaga › Andalucía** (2): 
  - Málaga CF  (1) Malaga
  - Málaga CF B  (1) Malaga B
- **Palma de Mallorca › Islas Baleares** (2): 
  - RCD Mallorca  (1) Mallorca
  - RCD Mallorca B  (1) Mallorca B
- **Valencia › Comunidad Valenciana** (2): 
  - Levante UD  (1) Levante
  - Valencia CF  (1) Valencia
- **Villarreal › Comunidad Valenciana** (2): 
  - Villarreal CF  (2) Villarreal • Villareal
  - Villarreal CF B  (1) Villarreal B
- **Albacete › Castilla-La Mancha** (1): Albacete Balompié  (1) Albacete
- **Alcorcón › Comunidad de Madrid** (1): AD Alcorcón  (1) Alcorcon
- **Alcoy › Comunidad Valenciana** (1): CD Alcoyano  (1) Alcoyano
- **Algeciras › Andalucía** (1): Algeciras CF  (1) Algeciras
- **Almendralejo › Extremadura** (1): CF Extremadura  (1) Extremadura
- **Almería › Andalucía** (1): UD Almería  (1) Almeria
- **Badajoz › Extremadura** (1): CD Badajoz  (1) Badajoz
- **Burgos › Castilla y León** (1): Burgos CF  (1) Burgos
- **Cartagena › Región de Murcia** (1): FC Cartagena  (1) Cartagena
- **Castellón de la Plana › Comunidad Valenciana** (1): CD Castellón  (1) Castellon
- **Cádiz › Andalucía** (1): Cádiz CF  (1) Cadiz
- **Córdoba › Andalucía** (1): Córdoba CF  (1) Cordoba
- **Eibar › País Vasco** (1): SD Eibar  (1) Eibar
- **Elche › Comunidad Valenciana** (1): Elche CF  (1) Elche
- **Ferrol › Galicia** (1): Racing Ferrol  (1) Ferrol
- **Gerona › Cataluña** (1): Girona FC  (1) Girona
- **Gijón › Asturias** (1): Sporting Gijón  (1) Sp Gijon
- **Guadalajara › Castilla-La Mancha** (1): CD Guadalajara  (1) Guadalajara
- **Huesca › Aragón** (1): SD Huesca  (1) Huesca
- **Jaén › Andalucía** (1): Real Jaén CF  (1) Jaen
- **La Coruña › Galicia** (1): RCD La Coruña  (1) La Coruna
- **Miranda de Ebro › Castilla y León** (1): CD Mirandés  (1) Mirandes
- **Mérida › Extremadura** (1): CP Mérida  (1) Merida
- **San Sebastián › País Vasco** (1): Real Sociedad  (1) Sociedad
- **Santiago de Compostela › Galicia** (1): SD Compostela  (1) Compostela
- **Tarragona › Cataluña** (1): Gimnàstic Tarragona  (1) Gimnastic
- **Vigo › Galicia** (1): RC Celta Vigo  (1) Celta
- **Vitoria › País Vasco** (1): Deportivo Alavés  (1) Alaves
- **Écija › Andalucía** (1): Écija Balompié  (1) Ecija




### Season

- **AD Alcorcón** - 8 seasons in 1 level
  - 2 (8): 2018........2010 (8)
- **Albacete Balompié** - 21 seasons in 2 levels
  - 1 (5): 2005..2003 (2) 1996...1993 (3)
  - 2 (16): 2017-18 2016..2014 (2) 2011......2005 (6) 2003.......1996 (7)
  - ⇑ (1) / ⇓ (2): 2  **?? 2016-17 ??** 2 2  **?? 2013-14 ??** 2 2 2 2 2 2 ⇓1 1 ⇑2 2 2 2 2 2 2 ⇓1 1 1 
- **Algeciras CF** - 1 season in 1 level
  - 2 (1): 2003-04
- **Alicante CF** - 1 season in 1 level
  - 2 (1): 2008-09
- **Athletic Club Bilbao** - 25 seasons in 1 level
  - 1 (25): 2018.........................1993 (25)
- **Athletic Club Bilbao B** - 1 season in 1 level
  - 2 (1): 2015-16
- **Atlético Madrid** - 25 seasons in 2 levels
  - 1 (23): 2018................2002 (16) 2000.......1993 (7)
  - 2 (2): 2002..2000 (2)
  - ⇑ (1) / ⇓ (1): 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 ⇑2 2 ⇓1 1 1 1 1 1 1 
- **Atlético Madrid B** - 4 seasons in 1 level
  - 2 (4): 2000....1996 (4)
- **Burgos CF** - 1 season in 1 level
  - 2 (1): 2001-02
- **CA Osasuna** - 23 seasons in 2 levels
  - 1 (16): 2016-17 2014..............2000 (14) 1993-94
  - 2 (7): 2017-18 2016..2014 (2) 2000....1996 (4)
  - ⇑ (2) / ⇓ (3): 2 ⇓1 ⇑2 2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 ⇑2 2 2 2  **?? 1995-96 ??** ⇓1 
- **CD Alcoyano** - 1 season in 1 level
  - 2 (1): 2011-12
- **CD Badajoz** - 7 seasons in 1 level
  - 2 (7): 2003.......1996 (7)
- **CD Castellón** - 5 seasons in 1 level
  - 2 (5): 2010.....2005 (5)
- **CD Guadalajara** - 2 seasons in 1 level
  - 2 (2): 2013..2011 (2)
- **CD Leganés** - 12 seasons in 2 levels
  - 1 (2): 2018..2016 (2)
  - 2 (10): 2016..2014 (2) 2004........1996 (8)
  - ⇑ (1): 1 1 ⇑2 2  **?? 2013-14 ??** 2 2 2 2 2 2 2 2 
- **CD Logroñés** - 6 seasons in 2 levels
  - 1 (3): 1996-97 1995..1993 (2)
  - 2 (3): 2000...1997 (3)
  - ⇓ (1): 2 2 2 ⇓1  **?? 1995-96 ??** 1 1 
- **CD Lugo** - 6 seasons in 1 level
  - 2 (6): 2018......2012 (6)
- **CD Mirandés** - 5 seasons in 1 level
  - 2 (5): 2017.....2012 (5)
- **CD Numancia** - 21 seasons in 2 levels
  - 1 (4): 2008-09 2004-05 2001..1999 (2)
  - 2 (17): 2018.........2009 (9) 2008...2005 (3) 2004...2001 (3) 1999..1997 (2)
  - ⇑ (3) / ⇓ (3): 2 2 2 2 2 2 2 2 2 ⇓1 ⇑2 2 2 ⇓1 ⇑2 2 2 ⇓1 1 ⇑2 2 
- **CD Ourense** - 3 seasons in 1 level
  - 2 (3): 1999...1996 (3)
- **CD Tenerife** - 23 seasons in 2 levels
  - 1 (8): 2009-10 2001-02 1999......1993 (6)
  - 2 (15): 2018.....2013 (5) 2010-11 2009.......2002 (7) 2001..1999 (2)
  - ⇑ (2) / ⇓ (3): 2 2 2 2 2  **?? 2012-13 ??** 2 ⇓1 ⇑2 2 2 2 2 2 2 ⇓1 ⇑2 2 ⇓1 1 1 1 1 1 
- **CD Toledo** - 4 seasons in 1 level
  - 2 (4): 2000....1996 (4)
- **CE Sabadell** - 4 seasons in 1 level
  - 2 (4): 2015....2011 (4)
- **CF Ciudad de Murcia** - 4 seasons in 1 level
  - 2 (4): 2007....2003 (4)
- **CF Extremadura** - 6 seasons in 2 levels
  - 1 (2): 1998-99 1996-97
  - 2 (4): 2002...1999 (3) 1997-98
  - ⇑ (1) / ⇓ (2): 2 2 2 ⇓1 ⇑2 ⇓1 
- **CF Reus** - 2 seasons in 1 level
  - 2 (2): 2018..2016 (2)
- **CP Mérida** - 5 seasons in 2 levels
  - 1 (2): 1997-98 1995-96
  - 2 (3): 2000..1998 (2) 1996-97
  - ⇑ (1) / ⇓ (2): 2 2 ⇓1 ⇑2 ⇓1 
- **Cultural Leonesa** - 1 season in 1 level
  - 2 (1): 2017-18
- **Cádiz CF** - 8 seasons in 2 levels
  - 1 (1): 2005-06
  - 2 (7): 2018..2016 (2) 2009-10 2008..2006 (2) 2005..2003 (2)
  - ⇑ (1) / ⇓ (1): 2 2  **?? 2015-16 ??** 2  **?? 2008-09 ??** 2 2 ⇓1 ⇑2 2 
- **Córdoba CF** - 17 seasons in 2 levels
  - 1 (1): 2014-15
  - 2 (16): 2018...2015 (3) 2014.......2007 (7) 2005......1999 (6)
  - ⇑ (1) / ⇓ (1): 2 2 2 ⇓1 ⇑2 2 2 2 2 2 2  **?? 2006-07 ??** 2 2 2 2 2 2 
- **Deportivo Alavés** - 18 seasons in 2 levels
  - 1 (8): 2018..2016 (2) 2005-06 2003.....1998 (5)
  - 2 (10): 2016...2013 (3) 2009...2006 (3) 2005..2003 (2) 1998..1996 (2)
  - ⇑ (3) / ⇓ (2): 1 1 ⇑2 2 2  **?? 2012-13 ??** 2 2 2 ⇓1 ⇑2 2 ⇓1 1 1 1 1 ⇑2 2 
- **Elche CF** - 19 seasons in 2 levels
  - 1 (2): 2015..2013 (2)
  - 2 (17): 2017..2015 (2) 2013..............1999 (14) 1997-98
  - ⇑ (1) / ⇓ (1): 2 2 ⇓1 1 ⇑2 2 2 2 2 2 2 2 2 2 2 2 2 2  **?? 1998-99 ??** 2 
- **FC Barcelona** - 25 seasons in 1 level
  - 1 (25): 2018.........................1993 (25)
- **FC Barcelona B** - 8 seasons in 1 level
  - 2 (8): 2017-18 2015.....2010 (5) 1998-99 1996-97
- **FC Cartagena** - 3 seasons in 1 level
  - 2 (3): 2012...2009 (3)
- **Getafe CF** - 18 seasons in 2 levels
  - 1 (13): 2017-18 2016............2004 (12)
  - 2 (5): 2016-17 2004..2002 (2) 2001..1999 (2)
  - ⇑ (2) / ⇓ (1): 1 ⇑2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 ⇑2 2  **?? 2001-02 ??** 2 2 
- **Gimnàstic Tarragona** - 12 seasons in 2 levels
  - 1 (1): 2006-07
  - 2 (11): 2018...2015 (3) 2012.....2007 (5) 2006..2004 (2) 2001-02
  - ⇑ (1) / ⇓ (1): 2 2 2  **?? 2014-15 ??** 2 2 2 2 2 ⇓1 ⇑2 2  **?? 2003-04 ??** 2 
- **Girona FC** - 10 seasons in 2 levels
  - 1 (1): 2017-18
  - 2 (9): 2017.........2008 (9)
  - ⇑ (1): 1 ⇑2 2 2 2 2 2 2 2 2 
- **Granada 74** - 1 season in 1 level
  - 2 (1): 2007-08
- **Granada CF** - 8 seasons in 2 levels
  - 1 (6): 2017......2011 (6)
  - 2 (2): 2017-18 2010-11
  - ⇑ (1) / ⇓ (1): 2 ⇓1 1 1 1 1 1 ⇑2 
- **Hércules CF** - 12 seasons in 2 levels
  - 1 (2): 2010-11 1996-97
  - 2 (10): 2014...2011 (3) 2010.....2005 (5) 1999..1997 (2)
  - ⇑ (1) / ⇓ (2): 2 2 2 ⇓1 ⇑2 2 2 2 2  **?? 2004-05 ??** 2 2 ⇓1 
- **Levante UD** - 21 seasons in 2 levels
  - 1 (10): 2017-18 2016......2010 (6) 2008..2006 (2) 2004-05
  - 2 (11): 2016-17 2010..2008 (2) 2005-06 2004.....1999 (5) 1998..1996 (2)
  - ⇑ (4) / ⇓ (3): 1 ⇑2 ⇓1 1 1 1 1 1 ⇑2 2 ⇓1 1 ⇑2 ⇓1 ⇑2 2 2 2 2  **?? 1998-99 ??** 2 2 
- **Lorca FC** - 3 seasons in 1 level
  - 2 (3): 2017-18 2007..2005 (2)
- **Málaga CF** - 20 seasons in 2 levels
  - 1 (17): 2018..........2008 (10) 2006.......1999 (7)
  - 2 (3): 2008..2006 (2) 1998-99
  - ⇑ (2) / ⇓ (1): 1 1 1 1 1 1 1 1 1 1 ⇑2 2 ⇓1 1 1 1 1 1 1 ⇑2 
- **Málaga CF B** - 3 seasons in 1 level
  - 2 (3): 2006...2003 (3)
- **Polideportivo Ejido** - 7 seasons in 1 level
  - 2 (7): 2008.......2001 (7)
- **Pontevedra CF** - 1 season in 1 level
  - 2 (1): 2004-05
- **RC Celta Vigo** - 25 seasons in 2 levels
  - 1 (19): 2018......2012 (6) 2007..2005 (2) 2004...........1993 (11)
  - 2 (6): 2012.....2007 (5) 2004-05
  - ⇑ (2) / ⇓ (2): 1 1 1 1 1 1 ⇑2 2 2 2 2 ⇓1 1 ⇑2 ⇓1 1 1 1 1 1 1 1 1 1 1 
- **RCD Español** - 24 seasons in 1 level
  - 1 (24): 2018........................1994 (24)
- **RCD La Coruña** - 25 seasons in 2 levels
  - 1 (23): 2018....2014 (4) 2012-13 2011..................1993 (18)
  - 2 (2): 2013-14 2011-12
  - ⇑ (2) / ⇓ (2): 1 1 1 1 ⇑2 ⇓1 ⇑2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 
- **RCD Mallorca** - 21 seasons in 2 levels
  - 1 (16): 2013................1997 (16)
  - 2 (5): 2017....2013 (4) 1996-97
  - ⇑ (1) / ⇓ (1): 2 2 2 2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 ⇑2 
- **RCD Mallorca B** - 1 season in 1 level
  - 2 (1): 1998-99
- **Racing Ferrol** - 6 seasons in 1 level
  - 2 (6): 2007-08 2006..2004 (2) 2003...2000 (3)
- **Rayo Vallecano** - 20 seasons in 2 levels
  - 1 (12): 2016.....2011 (5) 2003....1999 (4) 1997..1995 (2) 1993-94
  - 2 (8): 2018..2016 (2) 2011...2008 (3) 2003-04 1999..1997 (2)
  - ⇑ (2) / ⇓ (3): 2 2 ⇓1 1 1 1 1 ⇑2 2 2  **?? 2007-08 ??** 2 ⇓1 1 1 1 ⇑2 2 ⇓1 1  **?? 1994-95 ??** 1 
- **Real Betis** - 24 seasons in 2 levels
  - 1 (20): 2018...2015 (3) 2014...2011 (3) 2009........2001 (8) 2000......1994 (6)
  - 2 (4): 2014-15 2011..2009 (2) 2000-01
  - ⇑ (3) / ⇓ (3): 1 1 1 ⇑2 ⇓1 1 1 ⇑2 2 ⇓1 1 1 1 1 1 1 1 ⇑2 ⇓1 1 1 1 1 1 
- **Real Jaén CF** - 4 seasons in 1 level
  - 2 (4): 2013-14 2002..2000 (2) 1997-98
- **Real Madrid CF** - 25 seasons in 1 level
  - 1 (25): 2018.........................1993 (25)
- **Real Madrid CF B** - 5 seasons in 1 level
  - 2 (5): 2014..2012 (2) 2007..2005 (2) 1996-97
- **Real Murcia CF** - 13 seasons in 2 levels
  - 1 (2): 2007-08 2003-04
  - 2 (11): 2014...2011 (3) 2010..2008 (2) 2007...2004 (3) 2003...2000 (3)
  - ⇑ (2) / ⇓ (2): 2 2 2  **?? 2010-11 ??** 2 2 ⇓1 ⇑2 2 2 ⇓1 ⇑2 2 2 
- **Real Oviedo** - 13 seasons in 2 levels
  - 1 (8): 2001........1993 (8)
  - 2 (5): 2018...2015 (3) 2003..2001 (2)
  - ⇓ (1): 2 2 2  **?? 2014-15 ??** 2 2 ⇓1 1 1 1 1 1 1 1 
- **Real Racing Santander** - 21 seasons in 2 levels
  - 1 (18): 2012..........2002 (10) 2001........1993 (8)
  - 2 (3): 2014-15 2012-13 2001-02
  - ⇑ (1) / ⇓ (2): 2  **?? 2013-14 ??** 2 ⇓1 1 1 1 1 1 1 1 1 1 ⇑2 ⇓1 1 1 1 1 1 1 1 
- **Real Sociedad** - 25 seasons in 2 levels
  - 1 (22): 2018........2010 (8) 2007..............1993 (14)
  - 2 (3): 2010...2007 (3)
  - ⇑ (1) / ⇓ (1): 1 1 1 1 1 1 1 1 ⇑2 2 2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 
- **Real Unión** - 1 season in 1 level
  - 2 (1): 2009-10
- **Real Valladolid CF** - 25 seasons in 2 levels
  - 1 (16): 2014..2012 (2) 2010...2007 (3) 2004...........1993 (11)
  - 2 (9): 2018....2014 (4) 2012..2010 (2) 2007...2004 (3)
  - ⇑ (2) / ⇓ (3): 2 2 2 2 ⇓1 1 ⇑2 2 ⇓1 1 1 ⇑2 2 2 ⇓1 1 1 1 1 1 1 1 1 1 1 
- **Real Zaragoza** - 25 seasons in 2 levels
  - 1 (18): 2013....2009 (4) 2008.....2003 (5) 2002.........1993 (9)
  - 2 (7): 2018.....2013 (5) 2008-09 2002-03
  - ⇑ (2) / ⇓ (3): 2 2 2 2 2 ⇓1 1 1 1 ⇑2 ⇓1 1 1 1 1 ⇑2 ⇓1 1 1 1 1 1 1 1 1 
- **Recreativo Huelva** - 17 seasons in 2 levels
  - 1 (4): 2009...2006 (3) 2002-03
  - 2 (13): 2015......2009 (6) 2006...2003 (3) 2002....1998 (4)
  - ⇑ (2) / ⇓ (2): 2 2 2 2 2 2 ⇓1 1 1 ⇑2 2 2 ⇓1 ⇑2 2 2 2 
- **SD Compostela** - 8 seasons in 2 levels
  - 1 (4): 1998....1994 (4)
  - 2 (4): 2002-03 2001...1998 (3)
  - ⇓ (1): 2  **?? 2001-02 ??** 2 2 2 ⇓1 1 1 1 
- **SD Eibar** - 17 seasons in 2 levels
  - 1 (4): 2018....2014 (4)
  - 2 (13): 2013-14 2009..2007 (2) 2006..........1996 (10)
  - ⇑ (1): 1 1 1 1 ⇑2  **?? 2012-13 ??** 2 2  **?? 2006-07 ??** 2 2 2 2 2 2 2 2 2 2 
- **SD Huesca** - 8 seasons in 1 level
  - 2 (8): 2018...2015 (3) 2013.....2008 (5)
- **SD Ponferradina** - 6 seasons in 1 level
  - 2 (6): 2016....2012 (4) 2010-11 2006-07
- **Sevilla FC** - 25 seasons in 2 levels
  - 1 (22): 2018.................2001 (17) 1999-00 1997....1993 (4)
  - 2 (3): 2000-01 1999..1997 (2)
  - ⇑ (2) / ⇓ (2): 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 ⇑2 ⇓1 ⇑2 2 ⇓1 1 1 1 
- **Sevilla FC B** - 4 seasons in 1 level
  - 2 (4): 2018..2016 (2) 2009..2007 (2)
- **Sporting Gijón** - 25 seasons in 2 levels
  - 1 (11): 2017..2015 (2) 2012....2008 (4) 1998.....1993 (5)
  - 2 (14): 2017-18 2015...2012 (3) 2008..........1998 (10)
  - ⇑ (2) / ⇓ (3): 2 ⇓1 1 ⇑2 2 2 ⇓1 1 1 1 ⇑2 2 2 2 2 2 2 2 2 2 ⇓1 1 1 1 1 
- **Terrassa FC** - 3 seasons in 1 level
  - 2 (3): 2005...2002 (3)
- **UCAM Murcia** - 1 season in 1 level
  - 2 (1): 2016-17
- **UD Almería** - 17 seasons in 2 levels
  - 1 (6): 2015..2013 (2) 2011....2007 (4)
  - 2 (11): 2018...2015 (3) 2013..2011 (2) 2007.....2002 (5) 1996-97
  - ⇑ (2) / ⇓ (2): 2 2 2 ⇓1 1 ⇑2 2 ⇓1 1 1 1 ⇑2 2 2 2 2  **?? 2001-02 ??** 2 
- **UD Las Palmas** - 20 seasons in 2 levels
  - 1 (5): 2018...2015 (3) 2002..2000 (2)
  - 2 (15): 2015.........2006 (9) 2004..2002 (2) 2000....1996 (4)
  - ⇑ (2) / ⇓ (1): 1 1 1 ⇑2 2 2 2 2 2 2 2 2  **?? 2005-06 ??** 2 2 ⇓1 1 ⇑2 2 2 2 
- **UD Salamanca** - 15 seasons in 2 levels
  - 1 (3): 1999..1997 (2) 1995-96
  - 2 (12): 2011.....2006 (5) 2005......1999 (6) 1996-97
  - ⇑ (1) / ⇓ (2): 2 2 2 2 2  **?? 2005-06 ??** 2 2 2 2 2 2 ⇓1 1 ⇑2 ⇓1 
- **UD Vecindario** - 1 season in 1 level
  - 2 (1): 2006-07
- **UE Llagostera** - 2 seasons in 1 level
  - 2 (2): 2016..2014 (2)
- **UE Lleida** - 8 seasons in 2 levels
  - 1 (1): 1993-94
  - 2 (7): 2006..2004 (2) 2001.....1996 (5)
  - ⇓ (1): 2 2  **?? 2003-04 ??** 2 2 2 2 2  **?? 1995-96 ??** ⇓1 
- **Universidad Las Palmas** - 1 season in 1 level
  - 2 (1): 2000-01
- **Valencia CF** - 25 seasons in 1 level
  - 1 (25): 2018.........................1993 (25)
- **Villarreal CF** - 22 seasons in 2 levels
  - 1 (18): 2018.....2013 (5) 2012............2000 (12) 1998-99
  - 2 (4): 2012-13 1999-00 1998..1996 (2)
  - ⇑ (3) / ⇓ (2): 1 1 1 1 1 ⇑2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 ⇑2 ⇓1 ⇑2 2 
- **Villarreal CF B** - 3 seasons in 1 level
  - 2 (3): 2012...2009 (3)
- **Xerez CD** - 13 seasons in 2 levels
  - 1 (1): 2009-10
  - 2 (12): 2013...2010 (3) 2009........2001 (8) 1997-98
  - ⇑ (1) / ⇓ (1): 2 2 2 ⇓1 ⇑2 2 2 2 2 2 2 2  **?? 2000-01 ??** 2 
- **Écija Balompié** - 1 season in 1 level
  - 2 (1): 1996-97



