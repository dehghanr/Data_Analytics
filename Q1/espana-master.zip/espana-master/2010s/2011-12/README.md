

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Real Madrid CF                38  16  2  1  70:19   16  2  1  51:13   121:32  +89  100
 2. FC Barcelona                  38  17  1  1  73:11   11  6  2  41:18   114:29  +85   91
 3. Valencia CF                   38  11  4  4  40:20    6  6  7  19:24    59:44  +15   61
 4. Málaga CF                     38  13  3  3  35:21    4  4 11  19:32    54:53   +1   58
 5. Atlético Madrid               38  11  5  3  36:17    4  6  9  17:29    53:46   +7   56
 6. Levante UD                    38  11  3  5  33:19    5  4 10  21:31    54:50   +4   55
 7. CA Osasuna                    38  10  6  3  26:19    3  9  7  18:42    44:61  -17   54
 8. RCD Mallorca                  38   9  5  5  21:15    5  5  9  21:31    42:46   -4   52
 9. Sevilla FC                    38   9  4  6  32:25    4  7  8  16:22    48:47   +1   50
10. Athletic Club Bilbao          38   8  7  4  29:21    4  6  9  20:31    49:52   -3   49
11. Real Sociedad                 38   9  6  4  29:17    3  5 11  17:35    46:52   -6   47
12. Real Betis                    38   7  7  5  28:25    6  1 12  19:31    47:56   -9   47
13. Getafe CF                     38   8  6  5  24:19    4  5 10  16:32    40:51  -11   47
14. RCD Español                   38   9  4  6  31:24    3  6 10  15:32    46:56  -10   46
15. Rayo Vallecano                38   8  1 10  29:26    5  3 11  24:47    53:73  -20   43
16. Real Zaragoza                 38   8  4  7  19:24    4  3 12  17:37    36:61  -25   43
17. Granada CF                    38   8  5  6  22:20    4  1 14  13:36    35:56  -21   42
18. Villarreal CF                 38   6 10  3  26:20    3  4 12  13:33    39:53  -14   41
19. Sporting Gijón                38   7  4  8  24:26    3  3 13  18:43    42:69  -27   37
20. Real Racing Santander         38   3  7  9  11:24    1  8 10  17:39    28:63  -35   27
```

(Source: [`1-liga.csv`](1-liga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. RCD La Coruña                 42  18  2  1  47:20   11  2  8  29:25    76:45  +31   91
 2. RC Celta Vigo                 42  15  2  4  50:16   11  5  5  33:21    83:37  +46   85
 3. Real Valladolid CF            42  14  4  3  34:17    9  9  3  35:20    69:37  +32   82
 4. AD Alcorcón                   42  13  6  2  34:14    8  4  9  24:28    58:42  +16   73
 5. Hércules CF                   42  11  3  7  30:24   11  3  7  32:19    62:43  +19   72
 6. Córdoba CF                    42  14  6  1  35:14    6  5 10  17:29    52:43   +9   71
 7. UD Almería                    42  11  8  2  35:17    7  8  6  28:26    63:43  +20   70
 8. FC Barcelona B                42  10  4  7  35:26    6  7  8  28:27    63:53  +10   59
 9. UD Las Palmas                 42  11  6  4  32:21    5  4 12  26:38    58:59   -1   58
10. CD Numancia                   42  12  4  5  32:18    3  8 10  22:34    54:52   +2   57
11. Elche CF                      42   9  2 10  31:29    8  4  9  25:29    56:58   -2   57
12. Villarreal CF B               42   8  6  7  34:32    6  4 11  20:32    54:64  -10   52
13. SD Huesca                     42   8  6  7  22:24    6  3 12  27:39    49:63  -14   51
14. Xerez CD                      42   8  5  8  29:34    5  6 10  21:32    50:66  -16   50
15. Girona FC                     42   9  8  4  32:23    3  5 13  26:38    58:61   -3   49
16. CD Guadalajara                42   8  2 11  23:32    6  5 10  27:43    50:75  -25   49
17. Recreativo Huelva             42   6  6  9  27:27    6  5 10  22:25    49:52   -3   47
18. Real Murcia CF                42   7  4 10  24:35    6  4 11  25:32    49:67  -18   47
19. CE Sabadell                   42   9  7  5  29:28    2  6 13  16:36    45:64  -19   46
20. FC Cartagena                  42   6  8  7  23:27    3  5 13  14:31    37:58  -21   40
21. CD Alcoyano                   42   6  7  8  25:33    3  3 15  21:45    46:78  -32   37
22. Gimnàstic Tarragona           42   3  6 12  17:27    3  7 11  20:31    37:58  -21   31
```

(Source: [`2-liga2.csv`](2-liga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

