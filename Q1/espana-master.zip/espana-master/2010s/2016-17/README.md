

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Real Madrid CF                38  14  4  1  48:20   15  2  2  58:21   106:41  +65   93
 2. FC Barcelona                  38  15  3  1  64:17   13  3  3  52:20   116:37  +79   90
 3. Atlético Madrid               38  14  2  3  40:14    9  7  3  30:13    70:27  +43   78
 4. Sevilla FC                    38  14  4  1  39:16    7  5  7  30:33    69:49  +20   72
 5. Villarreal CF                 38  11  4  4  35:18    8  6  5  21:15    56:33  +23   67
 6. Real Sociedad                 38  10  5  4  30:24    9  2  8  29:29    59:53   +6   64
 7. Athletic Club Bilbao          38  13  4  2  36:18    6  2 11  17:25    53:43  +10   63
 8. RCD Español                   38   8  5  6  28:24    7  6  6  21:26    49:50   -1   56
 9. Deportivo Alavés              38   7  8  4  19:21    7  5  7  22:22    41:43   -2   55
10. SD Eibar                      38  10  3  6  29:21    5  6  8  27:30    56:51   +5   54
11. Málaga CF                     38  10  2  7  32:25    2  8  9  17:30    49:55   -6   46
12. Valencia CF                   38   8  4  7  32:32    5  3 11  24:33    56:65   -9   46
13. RC Celta Vigo                 38   9  2  8  30:32    4  4 11  23:37    53:69  -16   45
14. UD Las Palmas                 38   9  6  4  33:25    1  3 15  20:49    53:74  -21   39
15. Real Betis                    38   6  7  6  22:24    4  2 13  19:40    41:64  -23   39
16. RCD La Coruña                 38   7  5  7  27:23    1  7 11  16:38    43:61  -18   36
17. CD Leganés                    38   5  6  8  22:23    3  5 11  14:32    36:55  -19   35
18. Sporting Gijón                38   5  4 10  26:38    2  6 11  16:34    42:72  -30   31
19. CA Osasuna                    38   2  7 10  23:39    2  3 14  17:55    40:94  -54   22
20. Granada CF                    38   4  4 11  17:32    0  4 15  13:50    30:82  -52   20
```

(Source: [`1-liga.csv`](1-liga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Levante UD                    42  17  3  1  34:14    8  6  7  23:18    57:32  +25   84
 2. Girona FC                     42  12  6  3  39:20    8  4  9  26:25    65:45  +20   70
 3. Getafe CF                     42  13  7  1  34:13    5  7  9  21:30    55:43  +12   68
 4. CD Tenerife                   42  10  9  2  25:14    6  9  6  25:23    50:37  +13   66
 5. Cádiz CF                      42  10  8  3  28:14    6  8  7  27:26    55:40  +15   64
 6. SD Huesca                     42  11  5  5  34:20    5 10  6  19:23    53:43  +10   63
 7. Real Valladolid CF            42  12  5  4  27:16    6  4 11  25:31    52:47   +5   63
 8. Real Oviedo                   42  13  5  3  28:12    4  5 12  19:35    47:47        61
 9. CF Reus                       42   7  9  5  18:15    6  7  8  13:14    31:29   +2   55
10. CD Lugo                       42  11  3  7  27:22    3 10  8  22:30    49:52   -3   55
11. Córdoba CF                    42  10  6  5  24:21    4  7 10  18:31    42:52  -10   55
12. Rayo Vallecano                42  10  7  4  29:16    4  4 13  15:28    44:44        53
13. Sevilla FC B                  42   9  9  3  38:26    4  5 12  17:30    55:56   -1   53
14. Gimnàstic Tarragona           42   7  9  5  26:21    5  7  9  21:30    47:51   -4   52
15. UD Almería                    42  11  6  4  33:18    3  3 15  11:31    44:49   -5   51
16. Real Zaragoza                 42   8  6  7  28:24    4  8  9  22:28    50:52   -2   50
17. CD Numancia                   42   8  7  6  19:19    3 10  8  21:30    40:49   -9   50
18. AD Alcorcón                   42  10  5  6  24:17    3  6 12   8:26    32:43  -11   50
19. UCAM Murcia                   42   7  6  8  24:23    4  9  8  18:28    42:51   -9   48
20. RCD Mallorca                  42   7 11  3  22:19    2  7 12  20:31    42:50   -8   45
21. Elche CF                      42   6  7  8  27:33    5  3 13  22:30    49:63  -14   43
22. CD Mirandés                   42   6  7  8  24:32    3  7 11  16:34    40:66  -26   41
```

(Source: [`2-liga2.csv`](2-liga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

