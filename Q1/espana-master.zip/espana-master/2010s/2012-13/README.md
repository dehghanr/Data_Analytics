

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FC Barcelona                  38  18  1  0  63:15   14  3  2  52:25   115:40  +75  100
 2. Real Madrid CF                38  17  2  0  67:21    9  5  5  36:21   103:42  +61   85
 3. Atlético Madrid               38  14  2  3  42:12    9  5  5  23:19    65:31  +34   76
 4. Real Sociedad                 38  10  7  2  41:22    8  5  6  29:27    70:49  +21   66
 5. Valencia CF                   38  13  3  3  42:25    6  5  8  25:29    67:54  +13   65
 6. Málaga CF                     38  10  5  4  33:18    6  4  9  20:32    53:50   +3   57
 7. Real Betis                    38   9  5  5  28:18    7  3  9  29:38    57:56   +1   56
 8. Rayo Vallecano                38   9  3  7  27:29    7  2 10  23:37    50:66  -16   53
 9. Sevilla FC                    38  13  1  5  41:21    1  7 11  17:33    58:54   +4   50
10. Getafe CF                     38   9  4  6  25:23    4  4 11  18:34    43:57  -14   47
11. Levante UD                    38   8  4  7  25:26    4  6  9  15:31    40:57  -17   46
12. Athletic Club Bilbao          38   8  3  8  22:27    4  6  9  22:38    44:65  -21   45
13. RCD Español                   38   6  7  6  25:28    5  4 10  18:24    43:52   -9   44
14. Real Valladolid CF            38   7  6  6  29:26    4  4 11  20:32    49:58   -9   43
15. Granada CF                    38   6  6  7  21:21    5  3 11  16:33    37:54  -17   42
16. CA Osasuna                    38   7  5  7  15:14    3  4 12  18:36    33:50  -17   39
17. RC Celta Vigo                 38   7  6  6  23:21    3  1 15  14:31    37:52  -15   37
18. RCD Mallorca                  38   7  5  7  26:30    2  4 13  17:42    43:72  -29   36
19. RCD La Coruña                 38   6  5  8  23:26    2  6 11  24:44    47:70  -23   35
20. Real Zaragoza                 38   5  4 10  23:27    4  3 12  14:35    37:62  -25   34
```

(Source: [`1-liga.csv`](1-liga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Elche CF                      42  15  5  1  36:12    8  8  5  18:15    54:27  +27   82
 2. Villarreal CF                 42  14  5  2  44:18    7  9  5  24:20    68:38  +30   77
 3. UD Almería                    42  12  5  4  37:19   10  3  8  35:31    72:50  +22   74
 4. Girona FC                     42  15  3  3  47:17    6  5 10  27:39    74:56  +18   71
 5. AD Alcorcón                   42  14  3  4  35:19    7  3 11  22:36    57:55   +2   69
 6. UD Las Palmas                 42  11  7  3  37:20    7  5  9  25:35    62:55   +7   66
 7. SD Ponferradina               42  11  5  5  32:22    8  4  9  25:28    57:50   +7   66
 8. Real Madrid CF B              42  13  2  6  54:27    4  6 11  26:35    80:62  +18   59
 9. FC Barcelona B                42   8  8  5  43:35    7  4 10  33:36    76:71   +5   57
10. Sporting Gijón                42  10  6  5  35:19    5  5 11  25:34    60:53   +7   56
11. CD Lugo                       42  10  5  6  34:25    5  6 10  12:29    46:54   -8   56
12. CD Numancia                   42  11  6  4  32:16    2 10  9  21:39    53:55   -2   55
13. Córdoba CF                    42  11  4  6  33:17    4  5 12  22:38    55:55        54
14. Recreativo Huelva             42  11  3  7  29:25    4  6 11  17:32    46:57  -11   54
15. CE Sabadell                   42  10  6  5  33:26    4  4 13  21:43    54:69  -15   52
16. CD Mirandés                   42   9  6  6  19:17    4  7 10  16:34    35:51  -16   52
17. CD Guadalajara                42   8  7  6  32:26    4  7 10  14:27    46:53   -7   50
18. Hércules CF                   42   8  5  8  26:30    5  6 10  17:23    43:53  -10   50
19. Real Murcia CF                42   8  8  5  19:16    4  3 14  24:40    43:56  -13   47
20. Real Racing Santander         42   8  6  7  23:20    4  4 13  15:31    38:51  -13   46
21. SD Huesca                     42   7  8  6  28:25    4  4 13  18:33    46:58  -12   45
22. Xerez CD                      42   4  5 12  14:30    3  4 14  24:44    38:74  -36   30
```

(Source: [`2-liga2.csv`](2-liga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

