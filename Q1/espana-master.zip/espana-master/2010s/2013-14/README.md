

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Atlético Madrid               38  15  4  0  49:10   13  2  4  28:16    77:26  +51   90
 2. FC Barcelona                  38  16  2  1  64:15   11  4  4  36:18   100:33  +67   87
 3. Real Madrid CF                38  16  1  2  63:17   11  5  3  41:21   104:38  +66   87
 4. Athletic Club Bilbao          38  13  4  2  42:18    7  6  6  24:21    66:39  +27   70
 5. Sevilla FC                    38  11  4  4  40:21    7  5  7  29:31    69:52  +17   63
 6. Villarreal CF                 38   9  6  4  36:21    8  2  9  24:23    60:44  +16   59
 7. Real Sociedad                 38  11  4  4  38:19    5  7  7  24:36    62:55   +7   59
 8. Valencia CF                   38  10  3  6  35:24    3  7  9  16:29    51:53   -2   49
 9. RC Celta Vigo                 38   6  7  6  23:23    8  0 11  26:31    49:54   -5   49
10. Levante UD                    38   7  6  6  19:16    5  6  8  16:27    35:43   -8   48
11. Málaga CF                     38   8  2  9  24:21    4  7  8  15:25    39:46   -7   45
12. Rayo Vallecano                38   8  0 11  28:36    5  4 10  18:44    46:80  -34   43
13. RCD Español                   38   7  5  7  23:22    4  4 11  18:29    41:51  -10   42
14. Getafe CF                     38   6  6  7  20:24    5  3 11  15:30    35:54  -19   42
15. Granada CF                    38   7  1 11  18:22    5  4 10  14:34    32:56  -24   41
16. Elche CF                      38   6  8  5  13:12    3  5 11  17:38    30:50  -20   40
17. UD Almería                    38   6  6  7  26:31    5  1 13  17:40    43:71  -28   40
18. CA Osasuna                    38   6  5  8  20:25    4  4 11  12:37    32:62  -30   39
19. Real Valladolid CF            38   6  9  4  20:17    1  6 12  18:43    38:60  -22   36
20. Real Betis                    38   5  3 11  19:31    1  4 14  17:47    36:78  -42   25
```

(Source: [`1-liga.csv`](1-liga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. SD Eibar                      42  11  6  4  25:12    8  8  5  24:16    49:28  +21   71
 2. RCD La Coruña                 42   8  9  4  24:19   11  3  7  24:17    48:36  +12   69
 3. FC Barcelona B                42  12  2  7  34:20    8  4  9  26:27    60:47  +13   66
 4. Real Murcia CF                42  10  7  4  36:23    6 10  5  19:21    55:44  +11   65
 5. Sporting Gijón                42  12  6  3  39:21    4 10  7  24:30    63:51  +12   64
 6. UD Las Palmas                 42  10  5  6  27:20    8  4  9  24:30    51:50   +1   63
 7. Córdoba CF                    42   9  7  5  27:18    7  6  8  19:25    46:43   +3   61
 8. Recreativo Huelva             42   8  7  6  28:24    8  6  7  25:29    53:53        61
 9. AD Alcorcón                   42   9  7  5  20:12    7  4 10  26:28    46:40   +6   59
10. CE Sabadell                   42  14  4  3  34:18    3  4 14  18:41    52:59   -7   59
11. CD Numancia                   42   7  9  5  24:18    4 12  5  18:23    42:41   +1   54
12. CD Tenerife                   42  10  4  7  27:18    5  5 11  19:31    46:49   -3   54
13. CD Lugo                       42  10  5  6  28:21    4  7 10  13:27    41:48   -7   54
14. Real Zaragoza                 42   7  7  7  22:21    6  7  8  27:32    49:53   -4   53
15. Girona FC                     42   7 10  4  35:22    5  5 11  17:28    52:50   +2   51
16. Deportivo Alavés              42   6 10  5  32:29    7  2 12  25:28    57:57        51
17. SD Ponferradina               42  10  4  7  28:19    3  8 10  18:30    46:49   -3   51
18. RCD Mallorca                  42   8  6  7  27:26    4  9  8  19:31    46:57  -11   51
19. CD Mirandés                   42   9  6  6  26:24    4  5 12  13:32    39:56  -17   50
20. Real Madrid CF B              42   8  5  8  31:26    5  5 11  18:30    49:56   -7   49
21. Real Jaén CF                  42   9  5  7  27:21    3  7 11  16:28    43:49   -6   48
22. Hércules CF                   42   6  6  9  22:23    5  6 10  23:39    45:62  -17   45
```

(Source: [`2-liga2.csv`](2-liga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

