

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Real Madrid CF                38  15  3  1  45:10    8  6  5  31:19    76:29  +47   78
 2. RCD La Coruña                 38  12  5  2  42:15    8  6  5  26:17    68:32  +36   71
 3. FC Barcelona                  38  12  5  2  34:12    6  5  8  26:33    60:45  +15   64
 4. Real Betis                    38   9  8  2  27:9     6  8  5  19:16    46:25  +21   61
 5. Real Zaragoza                 38  13  4  2  39:21    5  3 11  17:30    56:51   +5   61
 6. Sevilla FC                    38   8  5  6  30:23    8  6  5  25:18    55:41  +14   59
 7. Athletic Club Bilbao          38  10  4  5  22:18    6  6  7  17:24    39:42   -3   58
 8. RCD Español                   38  11  7  1  35:9     3  8  8  16:26    51:35  +16   57
 9. Real Oviedo                   38  12  5  2  29:14    1  8 10  16:28    45:42   +3   52
10. Valencia CF                   38  10  5  4  33:17    3  7  9  20:31    53:48   +5   51
11. Real Sociedad                 38   8  6  5  39:21    4  8  7  17:23    56:44  +12   50
12. Real Racing Santander         38   8  7  4  25:15    5  3 11  17:32    42:47   -5   49
13. Atlético Madrid               38  10  4  5  39:24    3  5 11  17:30    56:54   +2   48
14. CD Tenerife                   38  10  6  3  31:13    3  3 13  26:44    57:57        48
15. RC Celta Vigo                 38   6  6  7  16:20    5  8  6  20:28    36:48  -12   47
16. SD Compostela                 38   8  6  5  23:21    3  6 10  21:35    44:56  -12   45
17. Albacete Balompié             38   6  7  6  23:29    4  7  8  21:32    44:61  -17   44
18. Sporting Gijón                38   6  8  5  25:24    2  4 13  17:43    42:67  -25   36
19. Real Valladolid CF            38   6  5  8  18:30    2  4 13   7:33    25:63  -38   33
20. CD Logroñés                   38   1  7 11  11:35    1  2 16   4:44    15:79  -64   15
```

(Source: [`1-liga.csv`](1-liga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

