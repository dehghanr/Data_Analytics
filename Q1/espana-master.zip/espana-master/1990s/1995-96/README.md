

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Atlético Madrid               42  13  4  4  40:19   13  5  3  35:13    75:32  +43   87
 2. Valencia CF                   42  16  3  2  43:16   10  2  9  34:35    77:51  +26   83
 3. FC Barcelona                  42  15  5  1  42:17    7  9  5  30:22    72:39  +33   80
 4. RCD Español                   42  11  8  2  34:13    9  6  6  29:23    63:36  +27   74
 5. CD Tenerife                   42  11  6  4  38:25    9  6  6  31:29    69:54  +15   72
 6. Real Madrid CF                42  12  3  6  42:22    8  7  6  33:29    75:51  +24   70
 7. Real Sociedad                 42  12  5  4  38:19    5  7  9  24:34    62:53   +9   63
 8. Real Betis                    42   9  6  6  39:30    7  8  6  22:24    61:54   +7   62
 9. RCD La Coruña                 42  11  6  4  37:22    5  7  9  26:22    63:44  +19   61
10. SD Compostela                 42  12  4  5  34:25    5  4 12  13:29    47:54   -7   59
11. RC Celta Vigo                 42   9 10  2  30:17    3  6 12  19:34    49:51   -2   52
12. Real Zaragoza                 42   7  5  9  27:27    4 10  7  24:32    51:59   -8   48
13. Athletic Club Bilbao          42   9  7  5  25:18    2  8 11  19:37    44:55  -11   48
14. Sevilla FC                    42   7  8  6  19:16    4  7 10  24:39    43:55  -12   48
15. Real Oviedo                   42   5  7  9  23:31    7  5  9  25:36    48:67  -19   48
16. Real Valladolid CF            42   7 10  4  30:24    4  4 13  27:38    57:62   -5   47
17. Real Racing Santander         42   6 10  5  25:27    5  4 12  22:42    47:69  -22   47
18. Sporting Gijón                42  10  3  8  39:32    3  4 14  12:28    51:60   -9   46
19. Rayo Vallecano                42   7  3 11  29:43    5  5 11  18:32    47:75  -28   44
20. CP Mérida                     42   8  6  7  22:20    2  6 13  15:42    37:62  -25   42
21. Albacete Balompié             42   7  7  7  31:28    3  5 13  24:53    55:81  -26   42
22. UD Salamanca                  42   7  4 10  34:34    1  5 15  19:48    53:82  -29   33
```

(Source: [`1-liga.csv`](1-liga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

