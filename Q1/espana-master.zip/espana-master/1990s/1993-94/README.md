

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FC Barcelona                  38  16  1  2  56:17    9  5  5  35:25    91:42  +49   81
 2. RCD La Coruña                 38  13  5  1  36:7     9  7  3  18:11    54:18  +36   78
 3. Real Zaragoza                 38  14  3  2  46:17    5  5  9  25:30    71:47  +24   65
 4. Real Madrid CF                38  11  4  4  33:19    8  3  8  28:30    61:49  +12   64
 5. Athletic Club Bilbao          38  11  6  2  39:16    5  5  9  22:31    61:47  +14   59
 6. Sevilla FC                    38  10  4  5  32:18    5  8  6  24:24    56:42  +14   57
 7. Valencia CF                   38  10  6  3  37:24    4  6  9  18:26    55:50   +5   54
 8. Real Racing Santander         38  11  4  4  31:16    4  4 11  13:26    44:42   +2   53
 9. CD Tenerife                   38  12  4  3  30:17    3  2 14  20:40    50:57   -7   51
10. Sporting Gijón                38   9  3  7  27:20    6  2 11  15:37    42:57  -15   50
11. Real Oviedo                   38   9  3  7  25:21    3 10  6  18:28    43:49   -6   49
12. Atlético Madrid               38  11  3  5  32:21    2  6 11  22:33    54:54        48
13. Real Sociedad                 38   8  8  3  23:17    4  4 11  15:30    38:47   -9   48
14. Albacete Balompié             38   8  8  3  33:25    2  7 10  16:33    49:58   -9   45
15. RC Celta Vigo                 38   9  5  5  25:23    2  6 11  16:28    41:51  -10   44
16. CD Logroñés                   38   6  8  5  28:25    3  7  9  19:33    47:58  -11   42
17. Rayo Vallecano                38   7  6  6  26:24    2  7 10  14:34    40:58  -18   40
18. Real Valladolid CF            38   4 10  5  14:18    4  4 11  14:33    28:51  -23   38
19. UE Lleida                     38   3  8  8  12:19    4  5 10  17:29    29:48  -19   34
20. CA Osasuna                    38   6  7  6  20:19    2  3 14  14:44    34:63  -29   34
```

(Source: [`1-liga.csv`](1-liga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

